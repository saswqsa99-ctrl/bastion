
import os
import re

base_dir = '/Users/elnaila.agab/Desktop/My Home/MAIN_FILES/Lalan/'

def normalize_add_property():
    for filename in os.listdir(base_dir):
        if filename.endswith('.html') and '_ar' not in filename and '_tr' not in filename and '_en' not in filename:
            filepath = os.path.join(base_dir, filename)
            with open(filepath, 'r') as f:
                content = f.read()
            
            # Regex to find "add property" with whitespace/newlines between
            # <i class="fa fa-plus"></i> add\s+property</a>
            # We want to replace it with <i class="fa fa-plus"></i> add property</a>
            
            new_content = re.sub(
                r'(<i class="fa fa-plus"></i>\s*add)\s+(property</a>)',
                r'\1 \2',
                content,
                flags=re.IGNORECASE | re.DOTALL
            )
            
            if content != new_content:
                print(f"Fixed {filename}")
                with open(filepath, 'w') as f:
                    f.write(new_content)

if __name__ == "__main__":
    normalize_add_property()
