#!/usr/bin/env python3
"""
Update all internal links in HTML files after reorganization
"""

import os
import re
from pathlib import Path

# Base directory
BASE_DIR = Path(__file__).parent.parent

# Mapping of old paths to new paths
PATH_MAPPINGS = {
    # Home pages
    'home-map.html': 'home/home-map.html',
    'home-map_ar.html': 'home/home-map_ar.html',
    'home-map_tr.html': 'home/home-map_tr.html',
    'home-property.html': 'home/home-property.html',
    'home-property_ar.html': 'home/home-property_ar.html',
    'home-property_tr.html': 'home/home-property_tr.html',
    'home-splash.html': 'home/home-splash.html',
    'home-splash_ar.html': 'home/home-splash_ar.html',
    'home-splash_tr.html': 'home/home-splash_tr.html',
    
    # Properties
    'properties-grid.html': 'properties/properties-grid.html',
    'properties-grid_ar.html': 'properties/properties-grid_ar.html',
    'properties-grid_tr.html': 'properties/properties-grid_tr.html',
    'properties-list.html': 'properties/properties-list.html',
    'properties-list_ar.html': 'properties/properties-list_ar.html',
    'properties-list_tr.html': 'properties/properties-list_tr.html',
    'properties-grid-split.html': 'properties/properties-grid-split.html',
    'properties-grid-split_ar.html': 'properties/properties-grid-split_ar.html',
    'properties-grid-split_tr.html': 'properties/properties-grid-split_tr.html',
    'properties-list-split.html': 'properties/properties-list-split.html',
    'properties-list-split_ar.html': 'properties/properties-list-split_ar.html',
    'properties-list-split_tr.html': 'properties/properties-list-split_tr.html',
    'property-single-gallery.html': 'properties/property-single-gallery.html',
    'property-single-gallery_ar.html': 'properties/property-single-gallery_ar.html',
    'property-single-gallery_tr.html': 'properties/property-single-gallery_tr.html',
    'property-single-slider.html': 'properties/property-single-slider.html',
    'property-single-slider_ar.html': 'properties/property-single-slider_ar.html',
    'property-single-slider_tr.html': 'properties/property-single-slider_tr.html',
    'add-property.html': 'properties/add-property.html',
    'add-property_ar.html': 'properties/add-property_ar.html',
    'add-property_tr.html': 'properties/add-property_tr.html',
    'my-properties.html': 'properties/my-properties.html',
    'my-properties_ar.html': 'properties/my-properties_ar.html',
    'my-properties_tr.html': 'properties/my-properties_tr.html',
    'favourite-properties.html': 'properties/favourite-properties.html',
    'favourite-properties_ar.html': 'properties/favourite-properties_ar.html',
    'favourite-properties_tr.html': 'properties/favourite-properties_tr.html',
    
    # Agents
    'agents.html': 'agents/agents.html',
    'agents_ar.html': 'agents/agents_ar.html',
    'agents_tr.html': 'agents/agents_tr.html',
    'agent-profile.html': 'agents/agent-profile.html',
    'agent-profile_ar.html': 'agents/agent-profile_ar.html',
    'agent-profile_tr.html': 'agents/agent-profile_tr.html',
    
    # Agencies
    'agency-list.html': 'agencies/agency-list.html',
    'agency-list_ar.html': 'agencies/agency-list_ar.html',
    'agency-list_tr.html': 'agencies/agency-list_tr.html',
    'agency-profile.html': 'agencies/agency-profile.html',
    'agency-profile_ar.html': 'agencies/agency-profile_ar.html',
    'agency-profile_tr.html': 'agencies/agency-profile_tr.html',
    
    # Blog
    'blog.html': 'blog/blog.html',
    'blog_ar.html': 'blog/blog_ar.html',
    'blog_tr.html': 'blog/blog_tr.html',
    'blog-single.html': 'blog/blog-single.html',
    'blog-single_ar.html': 'blog/blog-single_ar.html',
    'blog-single_tr.html': 'blog/blog-single_tr.html',
    'blog-sidebar-left.html': 'blog/blog-sidebar-left.html',
    'blog-sidebar-left_ar.html': 'blog/blog-sidebar-left_ar.html',
    'blog-sidebar-left_tr.html': 'blog/blog-sidebar-left_tr.html',
    'blog-sidebar-right.html': 'blog/blog-sidebar-right.html',
    'blog-sidebar-right_ar.html': 'blog/blog-sidebar-right_ar.html',
    'blog-sidebar-right_tr.html': 'blog/blog-sidebar-right_tr.html',
    
    # User
    'user-profile.html': 'user/user-profile.html',
    'user-profile_ar.html': 'user/user-profile_ar.html',
    'user-profile_tr.html': 'user/user-profile_tr.html',
    'social-profile.html': 'user/social-profile.html',
    'social-profile_ar.html': 'user/social-profile_ar.html',
    'social-profile_tr.html': 'user/social-profile_tr.html',
    
    # Pages
    'page-about.html': 'pages/page-about.html',
    'page-about_ar.html': 'pages/page-about_ar.html',
    'page-about_tr.html': 'pages/page-about_tr.html',
    'page-contact.html': 'pages/page-contact.html',
    'page-contact_ar.html': 'pages/page-contact_ar.html',
    'page-contact_tr.html': 'pages/page-contact_tr.html',
    'page-faq.html': 'pages/page-faq.html',
    'page-faq_ar.html': 'pages/page-faq_ar.html',
    'page-faq_tr.html': 'pages/page-faq_tr.html',
    'page-404.html': 'pages/page-404.html',
    'page-404_ar.html': 'pages/page-404_ar.html',
    'page-404_tr.html': 'pages/page-404_tr.html',
}

def update_links_in_file(file_path):
    """Update all internal links in a single HTML file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Update href links
        for old_path, new_path in PATH_MAPPINGS.items():
            # Match href="old_path" or href='old_path'
            content = re.sub(
                rf'href=["\']({re.escape(old_path)})["\']',
                f'href="{new_path}"',
                content
            )
        
        # Only write if content changed
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        return False
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return False

def update_asset_paths_in_subfolder_files():
    """Update asset paths for files in subfolders"""
    folders = ['home', 'properties', 'agents', 'agencies', 'blog', 'user', 'pages']
    
    for folder in folders:
        folder_path = BASE_DIR / folder
        if not folder_path.exists():
            continue
            
        for html_file in folder_path.glob('*.html'):
            try:
                with open(html_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                original_content = content
                
                # Update asset paths: assets/ -> ../assets/
                content = re.sub(
                    r'(href|src)=["\']assets/',
                    r'\1="../assets/',
                    content
                )
                
                # Update root-level page links to go up one level
                # index.html -> ../index.html
                content = re.sub(
                    r'href=["\']index\.html',
                    'href="../index.html',
                    content
                )
                content = re.sub(
                    r'href=["\']index_ar\.html',
                    'href="../index_ar.html',
                    content
                )
                content = re.sub(
                    r'href=["\']index_tr\.html',
                    'href="../index_tr.html',
                    content
                )
                
                if content != original_content:
                    with open(html_file, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"✓ Updated asset paths in {html_file.name}")
            except Exception as e:
                print(f"✗ Error processing {html_file}: {e}")

def main():
    print("🔄 Updating internal links in all HTML files...")
    print()
    
    # Update links in root index files
    root_files = ['index.html', 'index_ar.html', 'index_tr.html']
    for filename in root_files:
        file_path = BASE_DIR / filename
        if file_path.exists():
            if update_links_in_file(file_path):
                print(f"✓ Updated links in {filename}")
    
    print()
    print("🔄 Updating links in subfolder files...")
    print()
    
    # Update links in all moved files
    folders = ['home', 'properties', 'agents', 'agencies', 'blog', 'user', 'pages']
    for folder in folders:
        folder_path = BASE_DIR / folder
        if not folder_path.exists():
            continue
            
        for html_file in folder_path.glob('*.html'):
            if update_links_in_file(html_file):
                print(f"✓ Updated links in {folder}/{html_file.name}")
    
    print()
    print("🔄 Updating asset paths...")
    print()
    update_asset_paths_in_subfolder_files()
    
    print()
    print("✅ All links updated successfully!")
    print()
    print("📋 Summary:")
    print(f"   - Updated {len(PATH_MAPPINGS)} file path mappings")
    print(f"   - Updated asset paths in {len(folders)} folders")
    print()

if __name__ == '__main__':
    main()
