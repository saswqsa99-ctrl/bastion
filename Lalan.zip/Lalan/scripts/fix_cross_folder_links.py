#!/usr/bin/env python3
"""
Fix cross-folder navigation links after reorganization
This script updates links between subfolders (e.g., properties/ -> agents/)
"""

import os
import re
from pathlib import Path

# Base directory
BASE_DIR = Path(__file__).parent.parent

# All folders
FOLDERS = ['home', 'properties', 'agents', 'agencies', 'blog', 'user', 'pages']

# Mapping of filenames to their folders
FILE_TO_FOLDER = {}

def build_file_mapping():
    """Build a mapping of all HTML files to their folders"""
    global FILE_TO_FOLDER
    
    for folder in FOLDERS:
        folder_path = BASE_DIR / folder
        if folder_path.exists():
            for html_file in folder_path.glob('*.html'):
                FILE_TO_FOLDER[html_file.name] = folder

def fix_cross_folder_links():
    """Fix links between different subfolders"""
    print("🔄 Fixing cross-folder navigation links...")
    print()
    
    for current_folder in FOLDERS:
        folder_path = BASE_DIR / current_folder
        if not folder_path.exists():
            continue
        
        for html_file in folder_path.glob('*.html'):
            try:
                with open(html_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                original_content = content
                
                # Find all href links to HTML files
                # Pattern: href="something.html" or href='something.html'
                pattern = r'href=["\']([^"\']+\.html)["\']'
                
                def replace_link(match):
                    link = match.group(1)
                    
                    # Skip external links, anchors, and already correct paths
                    if link.startswith(('http://', 'https://', '#', '../', '/')):
                        return match.group(0)
                    
                    # Extract just the filename
                    filename = os.path.basename(link)
                    
                    # Check if this file is in our mapping
                    if filename in FILE_TO_FOLDER:
                        target_folder = FILE_TO_FOLDER[filename]
                        
                        # If same folder, keep as is (just filename)
                        if target_folder == current_folder:
                            return f'href="{filename}"'
                        # If different folder, use ../folder/filename
                        else:
                            return f'href="../{target_folder}/{filename}"'
                    
                    # If not in mapping, keep original
                    return match.group(0)
                
                content = re.sub(pattern, replace_link, content)
                
                if content != original_content:
                    with open(html_file, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"✓ Fixed links in {current_folder}/{html_file.name}")
                    
            except Exception as e:
                print(f"✗ Error processing {html_file}: {e}")

def main():
    print("=" * 60)
    print("Cross-Folder Navigation Link Fixer")
    print("=" * 60)
    print()
    
    # Build the file mapping
    print("📋 Building file mapping...")
    build_file_mapping()
    print(f"   Found {len(FILE_TO_FOLDER)} HTML files across {len(FOLDERS)} folders")
    print()
    
    # Fix cross-folder links
    fix_cross_folder_links()
    
    print()
    print("✅ All cross-folder links fixed!")
    print()
    print("📝 Examples of what was fixed:")
    print("   properties/properties-grid.html:")
    print("      agents.html → ../agents/agents.html")
    print("      blog.html → ../blog/blog.html")
    print("      page-about.html → ../pages/page-about.html")
    print()

if __name__ == '__main__':
    main()
