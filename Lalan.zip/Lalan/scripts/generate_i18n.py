import os
import glob
import re

# Directory containing the Lalan files
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Language Switcher HTML to inject
LANG_SWITCHER_TEMPLATE = """
                            <!-- Language Switcher -->
                            <li class="has-dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle menu-item"><i class="fa fa-globe" style="font-size: 18px;"></i></a>
                                <ul class="dropdown-menu">
                                    <li><a href="{en_link}">English</a></li>
                                    <li><a href="{ar_link}">العربية</a></li>
                                    <li><a href="{tr_link}">Türkçe</a></li>
                                </ul>
                            </li>
"""

NAVBAR_END_REGEX = re.compile(r'(</ul>\s*<!-- Module Signup)', re.DOTALL)
FALLBACK_NAVBAR_END_REGEX = re.compile(r'(</ul>\s*<div class="module)', re.DOTALL)

# Translation Dictionaries
AR_TRANSLATIONS = {
    # Navigation
    '>home</a>': '>الرئيسية</a>',
    '>Home</a>': '>الرئيسية</a>',
    '>Pages</a>': '>صفحات</a>',
    '>Page</a>': '>صفحة</a>',
    '>Profile</a>': '>الملف الشخصي</a>',
    '>Properties</a>': '>عقارات</a>',
    '>contact</a>': '>اتصل بنا</a>',
    '>Contact</a>': '>اتصل بنا</a>',
    
    # Submenus
    '>home search</a>': '>بحث رئيسي</a>',
    '>home map</a>': '>خريطة رئيسية</a>',
    '>home property</a>': '>عقارات رئيسية</a>',
    '>home splash</a>': '>صفحة ترحيب</a>',
    'Los Angeles': 'المنامة',
    'Los Angeles, CA': 'المنامة',
    'New York': 'الرياض',
    'Chicago': 'دبي',
    'Manhatten': 'القاهرة',
    '16 Properties': '16 عقار',
    '14 Properties': '14 عقار',
    '18 Properties': '18 عقار',
    '10 Properties': '10 عقار',
    'Property By City': 'عقارات حسب المدينة',
    'Find the most exclusive real estate opportunities in top-tier cities, carefully selected for quality and value.': 'اعثر على أكثر الفرص العقارية حصرية في المدن الكبرى، والتي تم اختيارها بعناية لضمان الجودة والقيمة.',

    # My Properties Page
    '>my properties<h1>': '>عقاراتي</h1>',
    '>my properties</li>': '>عقاراتي</li>',
    '>My Properties</a>': '>عقاراتي</a>',
    '>House in Sheffleld Ave</a>': '>منزل في شارع شيفيلد</a>',
    '2003 Sheffield Ave, Anderson, IN 46011': '2003 شارع شيفيلد، أندرسون، إنديانا 46011',
    '>2750 House in Urban St.</a>': '>2750 منزل في شارع إيربان</a>',
    '2750 Urban Street Dr, Anderson, IN 46011': '2750 شارع إيربان، المنامة، 46011',
    '>Apartment For Rent</a>': '>شقة للإيجار</a>',
    '1609 N Richmond St, Chicago, IL 60647': '1609 شارع ريتشموند، دبي، 60647',
    '>House in Miami Town</a>': '>منزل في وسط البلد</a>',
    '415 E North Water, Miami 60611': '415 شارع نورث ووتر، القاهرة، 60611',
    '>Edit</a>': '>تعديل</a>',
    ' sq ft</span>': ' قدم مربع</span>',

    # Page Headers & Breadcrumbs (General)
    '>Blog<h1>': '>المدونة</h1>',
    '>Blog</li>': '>المدونة</li>',
    '>Agents<h1>': '>الوكلاء</h1>',
    '>Agents</li>': '>الوكلاء</li>',
    '>Agency List<h1>': '>قائمة الوكالات</h1>',
    '>Agency List</li>': '>قائمة الوكالات</li>',
    '>Property Single<h1>': '>تفاصيل العقار</h1>',
    '>Property Single</li>': '>تفاصيل العقار</li>',
    '>Add Property<h1>': '>أضف عقار</h1>',
    '>Add Property</li>': '>أضف عقار</h1>',

    # Blog Details
    '>Read More</a>': '>اقرأ المزيد</a>',
    '>Comments</a>': '>تعليقات</a>',
    '>Leave a Comment</a>': '>اترك تعليقاً</a>',
    '>Recent Posts<h5>': '>أحدث التدوينات<h5>',
    '>Categories<h5>': '>التصنيفات<h5>',
    '>Archives<h5>': '>الأرشيف<h5>',
    '>Tags<h5>': '>الوسوم<h5>',
    '10 Quick Tips About Real Estate': '10 نصائح سريعة حول العقارات',
    ' Skillfully plan your homeâ\x80\x99s design': ' خطط بمهارة لتصميم منزلك',
    'Real Estate recent news': 'أخبار العقارات الأخيرة',
    'Buying a Home': 'شراء منزل',
    'Selling a Home': 'بيع منزل',
    'Rental': 'تأجير',
    'Architecture': 'هندسة معمارية',
    'Interior Design': 'تصميم داخلي',
    'Modern': 'حديث',
    'Luxury': 'فاخر',
    'Studio': 'استوديو',
    'Apartment': 'شقة',
    'House': 'منزل',

    # Agency Profile Page
    '>Agency Profile<h1>': '>ملف الوكالة</h1>',
    '>Agency Profile</li>': '>ملف الوكالة</li>',
    '>Properties List</h2>': '>قائمة العقارات</h2>',
    '>Contact Us</h2>': '>اتصل بنا</h2>',
    '>Our Agents</h2>': '>وكلائنا</h2>',
    'A committed real estate professional with extensive knowledge of the local': 'محترف عقاري ملتزم يتمتع بمعرفة واسعة بالسوق المحلية،',
    'market, dedicated to providing exceptional service and achieving the best': 'مكرس لتقديم خدمة استثنائية وتحقيق أفضل',
    'results for every client.': 'النتائج لكل عميل.',
    '>agents</a>': '>وكلاء</a>',
    '>All Agents</a>': '>كل الوكلاء</a>',
    '>agent profile</a>': '>ملف الوكيل</a>',
    '>agents</a>': '>وكلاء</a>',
    '>All Agents</a>': '>كل الوكلاء</a>',
    '>agent profile</a>': '>ملف الوكيل</a>',
    '>agencies</a>': '>وكالات</a>',
    '>all agencies</a>': '>كل الوكالات</a>',
    '>agency profile</a>': '>ملف الوكالة</a>',

    # Property Single Page Headers & Sections
    '>Single Property</h1>': '>تفاصيل العقار</h1>',
    '>Single Property</li>': '>تفاصيل العقار</li>',
    '>Gallery</h2>': '>المعرض</h2>',
    '>Description</h2>': '>الوصف</h2>',
    '>Features</h2>': '>المميزات</h2>',
    '>Location</h2>': '>الموقع</h2>',
    '>Floor Plans</h2>': '>مخططات الطوابق</h2>',
    '>Video</h2>': '>فيديو</h2>',
    '>Reviews</h2>': '>تقييمات</h2>',
    '>Leave a Review</h2>': '>اترك تقييماً</h2>',
    '>About Agent</h5>': '>عن الوكيل</h5>',
    '>Request a Showing</h5>': '>طلب معاينة</h5>',
    '>Featured Properties</h5>': '>عقارات مميزة</h5>',
    '>Send Request': '>أرسل الطلب',
    
    # Homepage Mixed Content
    '>Find Your Favorite Property</h1>': '>ابحث عن عقارك المفضل</h1>',
    'We provide you with an integrated real estate experience and clear': 'نقدم لك تجربة عقارية متكاملة وخطوات واضحة',
    'steps that start from searching and end with receiving the key to your new home.': 'تبدأ من البحث وتنتهي باستلام مفتاح منزلك الجديد.',
    'Browse available properties in the most prestigious cities and': 'تصفح العقارات المتاحة في أرقى المدن والمناطق',
    'regions, where we provide you with a comprehensive and diverse list.': 'حيث نوفر لك قائمة شاملة ومتنوعة.',
    '>Trusted Agents</h2>': '>وكلاء موثوقون</h2>',
    'A selection of the best real estate agents with high experience and': 'نخبة من أفضل الوكلاء العقاريين ذوي الخبرة والكفاءة العالية',
    'competence to help you make the best real estate decisions.': 'لمساعدتك في اتخاذ أفضل القرارات العقارية.',
    
    # Agents Page
    '>Agents</h1>': '>الوكلاء</h1>',
    '>Agents</li>': '>الوكلاء</li>',
    '>Buying Agent</h6>': '>وكيل شراء</h6>',
    '>Selling Agent</h6>': '>وكيل بيع</h6>',
    '>Real Estate Broker</h6>': '>وسيط عقاري</h6>',
    '>Realty Specialist</h6>': '>أخصائي عقارات</h6>',
    '>Sales Assistant</h6>': '>مساعد مبيعات</h6>',
    '>Assistant Broker</h6>': '>مساعد وسيط</h6>',
    'A professional real estate agent committed to providing the best consulting': 'وكيل عقاري محترف ملتزم بتقديم أفضل الخدمات الاستشارية',
    'services to ensure a successful experience for all clients.': 'لضمان تجربة ناجحة لجميع العملاء.',
    
    # Agent/Agency Profile
    '>Agent Profile</h1>': '>الملف الشخصي للوكيل</h1>',
    '>Agent Profile</li>': '>الملف الشخصي للوكيل</li>',
    '>Agency Profile</h1>': '>ملف الوكالة</h1>',
    '>Agency Profile</li>': '>ملف الوكالة</li>',
    '>My Properties</h2>': '>عقاراتي</h2>',
    '>Contact Us</h2>': '>اتصل بنا</h2>',
    '>Phone:</span>': '>هاتف:</span>',
    '>Email:</span>': '>بريد إلكتروني:</span>',
    '>Mobile:</span>': '>جوال:</span>',
    '>Website:</span>': '>موقع إلكتروني:</span>',
    '>Fax:</span>': '>فاكس:</span>',
    '>Email Address*</label>': '>البريد الإلكتروني*</label>',
    '>Phone Number</label>': '>رقم الهاتف</label>',
    '>Send Message': '>أرسل الرسالة',
    'A committed real estate professional with extensive knowledge of the local market,': 'محترف عقاري ملتزم ذو معرفة واسعة بالسوق المحلي،',
    'dedicated to providing exceptional service and achieving the best results for every': 'مكرس لتقديم خدمة استثنائية وتحقيق أفضل النتائج لكل',
    'client.': 'عميل.',
    
    # Agency List
    '>Agency List</h1>': '>قائمة الوكالات</h1>',
    '>Agency List</li>': '>قائمة الوكالات</li>',
    ' Property</span>': ' عقار</span>',
    'A leading real estate agency with over 15 years of experience in the local and': 'وكالة عقارية رائدة تتمتع بخبرة تزيد عن 15 عاماً في الأسواق المحلية و',
    'international markets, specializing in luxury residential and commercial': 'العالمية، متخصصة في العقارات السكنية والتجارية الفاخرة.',
    'properties. Our team of dedicated experts provides comprehensive consulting': 'فريقنا من الخبراء المخلصين يقدم خدمات استشارية شاملة',
    'services to help you find the perfect property that meets your needs and': 'لمساعدتك في العثور على العقار المثالي الذي يلبي احتياجاتك و',
    'investment goals.': 'أهدافك الاستثمارية.',
    'Our agency stands at the forefront of the real estate industry, offering a': 'تقف وكالتنا في طليعة صناعة العقارات، وتقدم',
    'curated selection of residential and commercial properties. We pride ourselves': 'مجموعة مختارة من العقارات السكنية والتجارية. نحن نفتخر',
    'on transparency, integrity, and a personalized approach that ensures every': 'بالشفافية والنزاهة والنهج الشخصي الذي يضمن لكل',
    'client makes an informed and successful decision.': 'عميل اتخاذ قرار مستنير وناجح.',
    
    # All Page Headers and Breadcrumbs
    '>About</h1>': '>عن الشركة</h1>',
    '>About</li>': '>عن الشركة</li>',
    '>Contact</h1>': '>اتصل بنا</h1>',
    '>Contact</li>': '>اتصل بنا</li>',
    '>FAQ</h1>': '>الأسئلة الشائعة</h1>',
    '>FAQ</li>': '>الأسئلة الشائعة</li>',
    '>Blog</h1>': '>المدونة</h1>',
    '>Blog</li>': '>المدونة</li>',
    '>Blog Left Sidebar</h1>': '>المدونة - الشريط الجانبي الأيسر</h1>',
    '>Blog Left Sidebar</li>': '>المدونة - الشريط الجانبي الأيسر</li>',
    '>Blog Right Sidebar</h1>': '>المدونة - الشريط الجانبي الأيمن</h1>',
    '>Blog Right Sidebar</li>': '>المدونة - الشريط الجانبي الأيمن</li>',
    '>Single Property</h1>': '>تفاصيل العقار</h1>',
    '>Single Property</li>': '>تفاصيل العقار</li>',
    '>user Profile</h1>': '>ملف المستخدم</h1>',
    '>user Profile</li>': '>ملف المستخدم</li>',
    '>my properties</h1>': '>عقاراتي</h1>',
    '>my properties</li>': '>عقاراتي</li>',
    '>favourite properties</h1>': '>عقاراتي المفضلة</h1>',
    '>favourite properties</li>': '>عقاراتي المفضلة</li>',
    '>Social Profile</h1>': '>الملف الاجتماعي</h1>',
    '>Social Profile</li>': '>الملف الاجتماعي</li>',

    '>Get In Touch</h6>': '>تواصل معنا</h6>',
    '>Company</h5>': '>الشركة</h5>',
    '>Learn More</h5>': '>روابط هامة</h5>',
    '>newsletter</h5>': '>النشرة البريدية</h5>',
    '86 Petersham town, New South Wales Wardll Street, Australia PA 6550': '86 مدينة بيترشام، نيو ساوث ويلز، شارع واردل، أستراليا PA 6550',
    '&copy; 2024 Lalan Real Estate, All Rights Reserved.': '&copy; 2024 لالان العقارية، جميع الحقوق محفوظة.',
    '>Any State</option>': '>أي منطقة</option>',
    '>Any City</option>': '>أي مدينة</option>',
    '>Any Locality</option>': '>أي موقع</option>',
    '>Any Neighborhood</option>': '>أي حي</option>',
    '>Any Type</option>': '>أي نوع</option>',
    '>Any Status</option>': '>أي حالة</option>',
    '>Beds</option>': '>أسرة</option>',
    '>Baths</option>': '>حمامات</option>',
    'Price Range: ': 'نطاق السعر: ',

    # Add Property Page
    '>Add Property</li>': '>أضف عقار</li>',
    '>Property Description</h4>': '>وصف العقار</h4>',
    '>Property Features</h4>': '>مميزات العقار</h4>',
    '>Property Gallery</h4>': '>معرض العقار</h4>',
    '>Property Location</h4>': '>موقع العقار</h4>',
    '>Property Title*</label>': '>عنوان العقار*</label>',
    '>Property Description*</label>': '>وصف العقار*</label>',
    '>Type</label>': '>النوع</label>',
    '>Status</label>': '>الحالة</label>',
    '>Location</label>': '>الموقع</label>',
    '>Bedrooms</label>': '>غرف النوم</label>',
    '>Bathrooms</label>': '>الحمامات</label>',
    '>Floors</label>': '>الطوابق</label>',
    '>Garages</label>': '>الكراجات</label>',
    '>Area</label>': '>المساحة</label>',
    '>Size</label>': '>الحجم</label>',
    '>Sale or Rent Price*</label>': '>سعر البيع أو الإيجار*</label>',
    '>Before Price Label</label>': '>تسمية السعر (سابقاً)</label>',
    '>After Price Label</label>': '>تسمية السعر (لاحقاً)</label>',
    '>Property ID*</label>': '>رقم العقار*</label>',
    '>Video URL</label>': '>رابط الفيديو</label>',
    '>Address*</label>': '>العنوان*</label>',
    '>Country</label>': '>الدولة</label>',
    '>City</label>': '>المدينة</label>',
    '>State</label>': '>المنطقة/المحافظة</label>',
    '>Zip/Postal Code</label>': '>الرمز البريدي</label>',
    '>Neighborhood</label>': '>الحي</label>',
    'value="Save Edits"': 'value="حفظ التعديلات"',
    '>Select property country</option>': '>اختر الدولة</option>',
    'placeholder="Enter your property address"': 'placeholder="أدخل عنوان عقارك"',
    'placeholder="Youtube, Vimeo, Dailymotion, etc.."': 'placeholder="يوتيوب، فيميو، ديلي موشن، إلخ.."',
    'placeholder="sq ft"': 'placeholder="قدم مربع"',
    'placeholder="ex: start from"': 'placeholder="مثال: يبدأ من"',
    'placeholder="ex: monthly"': 'placeholder="مثال: شهرياً"',

    # Property Features
    '>Center Cooling</p>': '>تكييف مركزي</p>',
    '>Balcony</p>': '>شرفة</p>',
    '>Pet Friendly</p>': '>يسمح بالحيوانات الأليفة</p>',
    '>Fire Alarm</p>': '>إنذار حريق</p>',
    '>Modern Kitchen</p>': '>مطبخ حديث</p>',
    '>Storage</p>': '>مخزن</p>',
    '>Heating</p>': '>تدفئة</p>',
    '>Pool</p>': '>مسبح</p>',
    '>Laundry</p>': '>غسيل</p>',
    '>Gym</p>': '>نادي رياضي</p>',
    '>Elevator</p>': '>مصعد</p>',
    '>Dish Washer</p>': '>غسالة صحون</p>',
    '>Emergency Exit</p>': '>مخرج طوارئ</p>',
    '>Sauna</p>': '>ساونا</p>',
    '>Dryer</p>': '>مجفف</p>',
    '>Barbeque</p>': '>منطقة شواء</p>',
    '>First Floor</a>': '>الطابق الأول</a>',
    '>Second Floor</a>': '>الطابق الثاني</a>',

    # Review Form
    '>Your Name*</label>': '>اسمك*</label>',
    '>Your Email*</label>': '>بريدك الإلكتروني*</label>',
    '>Rating*</label>': '>التقييم*</label>',
    '>Review*</label>': '>التعليق*</label>',
    '>Submit</button>': '>إرسال</button>',
    '>Message*</label>': '>الرسالة*</label>',
    'placeholder="(optional)"': 'placeholder="(ختياري)"',

    # Property City Links (Map IDs to Arabic Cities)
    'href="properties-grid.html?city=New York"': 'href="properties-grid.html?city=الرياض"',
    'href="properties-grid.html?city=Chicago"': 'href="properties-grid.html?city=دبي"',
    'href="properties-grid.html?city=Manhatten"': 'href="properties-grid.html?city=القاهرة"',
    'href="properties-grid.html?city=Los Angeles"': 'href="properties-grid.html?city=المنامة"',

    # Additional Address Mappings for Consistency
    '127 Kent Street, Sydney, NSW 2000': '127 شارع كينت، الرياض، 2000',
    '1035 Oglesby Ave, Chicago, IL 60617': '1035 شارع أوجلسبي، دبي، 60617',
    '34 Long St, Jersey City, NJ 07305': '34 شارع طويل، المنامة، 07305',
    '1445 N State Pkwy, Chicago, IL 60610': '1445 شارع الدولة، دبي، 60610',
    '>blog</a>': '>مدونة</a>',
    '>blog Grid</a>': '>شبكة المدونة</a>',
    '>blog single</a>': '>تدوينة</a>',
    '>page about</a>': '>من نحن</a>',
    '>page contact</a>': '>اتصل بنا</a>',
    '>page FAQ</a>': '>الأسئلة الشائعة</a>',
    '>user profile</a>': '>ملف المستخدم</a>',
    '>social profile</a>': '>الملف الاجتماعي</a>',
    '>my properties</a>': '>عقاراتي</a>',
    '>favourite properties</a>': '>المفضلة</a>',
    '>add property</a>': '>إضافة عقار</a>',
    '>Properties grid</a>': '>شبكة العقارات</a>',
    '>properties list</a>': '>قائمة العقارات</a>',
    '>properties single</a>': '>تفاصيل العقار</a>',
    
    # Actions & Buttons
    '>Login</a>': '>دخول</a>',
    '>Login with Facebook</a>': '>دخول عبر فيسبوك</a>',
    '>Sign In': 'تسجيل الدخول',
    '>Register</a>': '>تسجيل</a>',
    '>Register with Facebook</a>': '>تسجيل عبر فيسبوك</a>',
    '>Signup</a>': '>تسجيل</a>',
    '>signup</a>': '>تسجيل</a>',
    'value="Register"': 'value="تسجيل"',
    'value="Sign In"': 'value="دخول"',
    'placeholder="Email Address"': 'placeholder="البريد الإلكتروني"',
    'placeholder="Password"': 'placeholder="كلمة المرور"',
    'placeholder="Full Name"': 'placeholder="الاسم الكامل"',
    '>Remember Me</span>': '>تذكرني</span>',
    '>Forget your password?</a>': '>نسيت كلمة المرور؟</a>',
    '>I agree with all <a': '>أوافق على كل <a',
    '>Terms & Conditions</a>': '>الشروط والأحكام</a>',
    
    # About Us Page
    '>About<h1>': '>من نحن<h1>',
    '>About Us</a>': '>من نحن</a>',
    '>We Provide Lovable Experiment in the Real Estate Field</h2>': '>نقدم تجربة محببة في مجال العقارات</h2>',
    '>Our Vision</h3>': '>رؤيتنا</h3>',
    '>Our Goal</h3>': '>هدفنا</h3>',
    '>What We Provide?</h2>': '>ماذا نقدم؟</h2>',
    '>Presenting Your Property</h3>': '>عرض عقارك</h3>',
    '>Renting or Selling</h3>': '>تأجير أو بيع</h3>',
    '>Property Exchange</h3>': '>تبادل العقارات</h3>',
    '>Buying a Property</h3>': '>شراء عقار</h3>',
    '>About</li>': '>من نحن</li>',
    
    # Contact Page
    '>Contact<h1>': '>اتصل بنا</h1>',
    '>Contact</li>': '>اتصل بنا</li>',
    '>Get In Touch</h2>': '>تواصل معنا</h2>',
    '>Address</h3>': '>العنوان</h3>',
    '>Phone:</h3>': '>هاتف:</h3>',
    '>Email:</h3>': '>بريد إلكتروني:</h3>',
    '>Your Name*</label>': '>اسمك*</label>',
    '>Email Address*</label>': '>البريد الإلكتروني*</label>',
    '>Phone Number</label>': '>رقم الهاتف</label>',
    '>Message*</label>': '>الرسالة*</label>',
    'value="Send Message"': 'value="إرسال الرسالة"',
    '>Phone:</h3>': '>هاتف:</h3>',
    '>Email:</h3>': '>بريد إلكتروني:</h3>',
    '>Your Name*</label>': '>اسمك*</label>',
    '>Email Address*</label>': '>البريد الإلكتروني*</label>',
    '>Phone Number</label>': '>رقم الهاتف</label>',
    '>Message*</label>': '>الرسالة*</label>',
    'value="Send Message"': 'value="إرسال الرسالة"',
    'placeholder="(optional)"': 'placeholder="(اختياري)"',
    
    # Placeholders / Lorem Ipsum - Domain Specific
    '>What We Provide?<h2>\n                            <p class="heading--desc">Duis aute irure dolor in reprehed in volupted velit esse dolore</p>': 
    '>ماذا نقدم؟</h2>\n                            <p class="heading--desc">نقدم مجموعة شاملة من الخدمات العقارية المتكاملة لتلبية جميع احتياجاتك، من البحث عن العقار المثالي إلى إتمام الصفقة بنجاح.</p>',

    '<h3>Presenting Your Property</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>عرض عقارك</h3>\n                                <p>نساعدك في عرض عقارك بأفضل صورة ممكنة للوصول إلى المشترين المحتملين بسرعة وكفاءة عالية، مع توفير استشارات تسويقية متميزة لضمان أفضل النتائج.</p>',
    
    '<h3>Renting or Selling</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>تأجير أو بيع</h3>\n                                <p>سواء كنت ترغب في بيع عقارك أو تأجيره، نوفر لك الدعم القانوني والتسويقي لضمان أفضل العوائد وبأسرع وقت ممكن، مع إدارة كاملة للإجراءات.</p>',
    
    '<h3>Property Exchange</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>تبادل العقارات</h3>\n                                <p>نوفر خيارات مرنة لتبادل العقارات، مما يسهل عليك الانتقال إلى منزلك الجديد أو تنويع استثماراتك العقارية بكل سهولة ويسر دون تعقيدات.</p>',
    
    '<h3>Buying a Property</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>شراء عقار</h3>\n                                <p>اكتشف مجموعة واسعة من العقارات المميزة التي تناسب ميزانيتك ومتطلباتك، مع فريق متخصص لمساعدتك في اختيار المنزل الأمثل لك ولعائلتك.</p>',

    # Mixed Language Fixes (Header, Footer, CTA, Modal)
    '>add property</a>': '> أضف عقار</a>', 
    '> add property</a>': '> أضف عقار</a>', 
    '>About us</a>': '>من نحن</a>',
    '>Career</a>': '>الوظائف</a>',
    '>Services</a>': '>الخدمات</a>',
    '>Privacy</a>': '>السياسة والخصوصية</a>',
    '>Terms & Conditions</a>': '>الشروط والأحكام</a>',
    '>Account</a>': '>الحساب</a>',
    '>FAQ</a>': '>الأسئلة الشائعة</a>',
    '>Join our professional team & agents to start selling your house</h3>': '>انضم لفريقنا المحترف وابدأ بيع عقارك اليوم</h3>',
    '>86 Petersham town, New South Wales Wardll Street, Australia PA 6550</p>': '>86 مدينة بيترشام، نيو ساوث ويلز، شارع واردل، أستراليا PA 6550</p>',

    # FAQ Page
    '>Asked Questions</h2>': '>الأسئلة المتكررة</h2>',
    '>Find answers to the most common questions about buying, selling, and renting properties with our expert team.</p>': '>اعثر على إجابات للأسئلة الأكثر شيوعاً حول شراء وبيع وتأجير العقارات مع فريق الخبراء لدينا.</p>',
    '>What is a real estate broker?</a>': '>ما هو الوسيط العقاري؟</a>',
    '<p>A real estate broker is a professional who has completed advanced training and passed a state-licensing exam. They can work independently or hire other agents to work for them.</p>': '<p>الوسيط العقاري هو محترف أكمل تدريباً متقدماً واجتاز امتحان الترخيص الحكومي. يمكنهم العمل بشكل مستقل أو تعيين وكلاء آخرين للعمل معهم.</p>',
    '>Why should I use a real estate salesperson?</a>': '>لماذا يجب علي الاستعانة بوكيل عقاري؟</a>',
    'A professional agent provides expert market knowledge, handles complex paperwork, and negotiates the best price on your behalf, ensuring a smooth and legally sound transaction.': 'يوفر الوكيل المحترف معرفة متخصصة بالسوق، ويتولى التعامل مع الأوراق المعقدة، ويفاوض للحصول على أفضل سعر نيابة عنك، مما يضمن معاملة سلسة وقانونية.',
    '>What if my offer is rejected?</a>': '>ماذا لو تم رفض عرضي؟</a>',
    'If an offer is rejected, your agent will help you understand the reasons and guide you through making a counter-offer or searching for a better-suited property.': 'إذا تم رفض العرض، سيساعدك وكيلك في فهم الأسباب وتوجيهك لتقديم عرض مضاد أو البحث عن العقار أنسب.',
    '>Should I buy or continue to rent?</a>': '>هل يجب أن أشتري أم أستمر في الإيجار؟</a>',
    'Buying a property is along-term investment that builds equity and provides stability. Our experts can help you analyze the market to decide if now is the right time for you to buy.': 'شراء عقار هو استثمار طويل الأجل يبني حقوق الملكية ويوفر الاستقرار. يمكن لخبرائنا مساعدتك في تحليل السوق لتقرير ما إذا كان الوقت مناسباً للشراء.',

    # Missing Menu Items (Lowercase)
    '>properties grid</a>': '>شبكة العقارات</a>',
    '>properties grid split</a>': '>شبكة العقارات (تقسيم)</a>',
    '>properties list</a>': '>قائمة العقارات</a>',
    '>properties list split</a>': '>قائمة العقارات (تقسيم)</a>',
    '>single gallery</a>': '>معرض صور</a>',
    '>single slider</a>': '>شريط صور</a>',
    '>agent profile</a>': '>ملف الوكيل</a>',
    '>agency profile</a>': '>ملف الوكالة</a>',
    '>blog Grid</a>': '>شبكة المدونة</a>',
    '>blog Grid Right </a>': '>شبكة المدونة (يمين)</a>',
    '>blog Grid Left </a>': '>شبكة المدونة (يسار)</a>',
    '>blog single</a>': '>تدوينة</a>',
    '>page about</a>': '>من نحن</a>',
    '>page contact</a>': '>اتصل بنا</a>',
    '>page FAQ</a>': '>الأسئلة الشائعة</a>',
    '>page 404</a>': '>صفحة 404</a>',
    '>user profile</a>': '>ملف المستخدم</a>',
    '>social profile</a>': '>الملف الاجتماعي</a>',
    '>my properties</a>': '>عقاراتي</a>',
    '>favourite properties</a>': '>المفضلة</a>',
    
    # New Professional Content
    '>Trusted Real Estate Experts Since 2008</h2>': '>خبراء عقاريون موثوقون منذ عام 2008</h2>',
    '>To be the most reliable and innovative real estate partner, setting the standard for excellence and integrity in every transaction.</p>': '>أن نكون الشريك العقاري الأكثر موثوقية وابتكاراً، واضعين معايير التميز والنزاهة في كل صفقة.</p>',
    '>To deliver exceptional results for our clients through personalized service, expert market insights, and a global network of opportunities.</p>': '>تقديم نتائج استثنائية لعملائنا من خلال الخدمة الشخصية، ورؤى السوق الخبيرة، وشبكة عالمية من الفرص.</p>',
    '>Why Choose Us?</h2>': '>لماذا تختارنا؟</h2>',
    '>Our expertise and dedication ensure you receive the highest level of service and the best outcomes for your real estate journey.</p>': '>تضمن خبرتنا وتفانينا حصولك على أعلى مستوى من الخدمة وأفضل النتائج لرحلتك العقارية.</p>',
    'A leading real estate agency with over 15 years of experience in the local and international markets, specializing in luxury residential and commercial properties. Our team of dedicated experts provides comprehensive consulting services to help you find the perfect property that meets your needs and investment goals.': 'وكالة عقارية رائدة تتمتع بخبرة تزيد عن 15 عاماً في الأسواق المحلية والدولية، متخصصة في العقارات السكنية والتجارية الفاخرة. يقدم فريقنا من الخبراء المتفانين خدمات استشارية شاملة لمساعدتك في العثور على العقار المثالي الذي يلبي احتياجاتك وأهدافك الاستثمارية.',
    'Our agency stands at the forefront of the real estate industry, offering a curated selection of residential and commercial properties. We pride ourselves on transparency, integrity, and a personalized approach that ensures every client makes an informed and successful decision.': 'تقف وكالتنا في طليعة صناعة العقارات، حيث تقدم مجموعة مختارة من العقارات السكنية والتجارية. نحن نفخر بالشفافية والنزاهة والنهج الشخصي الذي يضمن لكل عميل اتخاذ قرار مستنير وناجح.',
    'With a presence in key metropolitan areas, we bring together a network of professional agents who are passionate about delivering exceptional results and building long-term value for our clients through expert consulting and dedicated support.': 'من خلال تواجدنا في المناطق الحضرية الرئيسية، نجمع شبكة من الوكلاء المحترفين المتحمسين لتقديم نتائج استثنائية وبناء قيمة طويلة الأجل لعملائنا من خلال الاستشارات الخبيرة والدعم المتفاني.',
    'Navigating the real estate market requires both patience and expertise. Whether you\'re a first-time homebuyer or a seasoned investor, understanding current trends and property values is essential for making a sound investment that grows over time.': 'يتطلب التنقل في سوق العقارات الصبر والخبرة. سواء كنت تشتري منزلاً لأول مرة أو مستثمراً متمرساً، فإن فهم الاتجاهات الحالية وقيم العقارات أمر ضروري لاتخاذ استثمار حكيم ينمو بمرور الوقت.',
    'Success in real estate is built on trust, transparency, and deep market insights. Every property has a story, and our mission is to help you find the one that perfectly aligns with your vision for the future.': 'النجاح في العقارات يقوم على الثقة والشفافية ورؤى السوق العميقة. كل عقار له قصة، ومهمتنا هي مساعدتك في العثور على العقار الذي يتماشى تماماً مع رؤيتك للمستقبل.',
    'From legal documentation to financial planning, the process should be handled with professional care. We ensure every detail is meticulously reviewed to provide you with peace of mind and a seamless experience.': 'من التوثيق القانوني إلى التخطيط المالي، يجب التعامل مع العملية بعناية مهنية. نحن نضمن مراجعة كل تفصيل بدقة لتزويدك براحة البال وتجربة سلسة.',
    'Our team of experts is dedicated to providing you with the most up-to-date information and personalized advice. We believe that an informed client is an empowered client, and we strive to be your most reliable source for all real estate matters and investment opportunities.': 'فريقنا من الخبراء مكرس لتزويدك بأأحدث المعلومات والنصائح الشخصية. نحن نؤمن بأن العميل المطلع هو عميل متمكن، ونسعى جاهدين لنكون مصدرك الأكثر موثوقية لجميع الأمور العقارية وفرص الاستثمار.',
    'Excellent service and very professional approach. The team helped me find my dream home in record time. Highly recommended for anyone looking for reliability and expertise in real estate.': 'خدمة ممتازة ونهج احترافي للغاية. ساعدني الفريق في العثور على منزل أحلامي في وقت قياسي. موصى به بشدة لكل من يبحث عن الموثوقية والخبرة في مجال العقارات.',
    'This stunning property offers modern architecture and premium finishes throughout. Featuring spacious living areas, a state-of-the-art kitchen, and breathtaking views, it provides the perfect blend of luxury and comfort for modern living.': 'يوفر هذا العقار المذهل هندسة معمارية حديثة وتشطيبات فاخرة في جميع الأنحاء. يتميز بمساحات معيشة واسعة ومطبخ حديث وإطلالات خلابة، ويوفر مزيجاً مثالياً من الفخامة والراحة للحياة العصرية.',
    'The layout has been meticulously designed to optimize space and ensure a seamless transition between indoor and outdoor environments, making it an ideal choice for families and professionals alike.': 'لقد تم تصميم المخطط بدقة لتحسين المساحة وضمان انتقال سلس بين البيئات الداخلية والخارجية، مما يجعله خياراً مثالياً للعائلات والمهنيين على حد سواء.',
    'The open-concept layout maximizes natural light and flow between living spaces. Each room is designed with attention to detail and high-quality materials to provide a functional and elegant environment for any lifestyle.': 'يزيد المخطط ذو المفهوم المفتوح من الضوء الطبيعي والتدفق بين مساحات المعيشة. تم تصميم كل غرفة بعناية بالتفاصيل ومواد عالية الجودة لتوفير بيئة وظيفية وأنيقة لأي نمط حياة.',
    "Expert advice on navigating the current housing market, from securing the best mortgage rates to finding your dream home.": "نصائح الخبراء حول التنقل في سوق العقارات الحالي، من تأمين أفضل أسعار الرهن العقاري إلى العثور على منزل أحلامك.",
    "Learn how to maximize your property's value with effective marketing strategies and home staging tips that attract buyers.": "تعرف على كيفية زيادة قيمة عقارك من خلال استراتيجيات التسويق الفعالة ونصائح تجهيز المنزل التي تجذب المشترين.",
    "A comprehensive guide to understanding property investments and how to build a diversified portfolio in today's landscape.": "دليل شامل لفهم الاستثمارات العقارية وكيفية بناء محفظة متنوعة في مشهد اليوم.",
    "Discover the power of visual storytelling in real estate and how professional video content can transform your property listings.": "اكتشف قوة السرد المرئي في العقارات وكيف يمكن لمحتوى الفيديو الاحترافي أن يغير قوائم عقاراتك.",
    "Build a loyal community and long-term client relationships by providing consistent, high-quality value through your digital platforms.": "قم ببناء مجتمع مخلص وعلاقات طويلة الأمد مع العملاء من خلال تقديم قيمة عالية الجودة باستمرار عبر منصاتك الرقمية.",
    "Master the art of email marketing to stay top-of-mind with your prospects and nurture leads into successful real estate transactions.": "أتقن فن التسويق عبر البريد الإلكتروني للبقاء في مقدمة اهتمامات عملائك المحتملين وتحويل العملاء المحتملين إلى صفقات عقارية ناجحة.",
    
    # Login Modal Specifics
    '>login</a>': '>دخول</a>',
    '>signup</a>': '>تسجيل</a>',
    '<span>or</span>': '<span>أو</span>',
    '<span>Remember Me</span>': '<span>تذكرني</span>',
    '<span>I agree with all <a href="#">Terms & Conditions</a></span>': '<span>أوافق على جميع <a href="#">الشروط والأحكام</a></span>',
    'placeholder="Email Address"': 'placeholder="البريد الإلكتروني"',
    'placeholder="Password"': 'placeholder="كلمة المرور"',
    'placeholder="Full Name"': 'placeholder="الاسم الكامل"',
    'value="Sign In"': 'value="تسجيل الدخول"',
    'value="Register"': 'value="تسجيل"',
    'Login with': 'تسجيل الدخول بواسطة',
    'Register with': 'التسجيل بواسطة',
    'Forget your': 'نسيت',
    '>Login</a>': '>دخول</a>',

    # Search & Filter Options
    '>Any Location</option>': '>أي موقع</option>',
    '>Any Type</option>': '>أي نوع</option>',
    '>Any Status</option>': '>أي حالة</option>',
    '>Apartment</option>': '>شقة</option>',
    '>House</option>': '>منزل</option>',
    '>Office</option>': '>مكتب</option>',
    '>Villa</option>': '>فيلا</option>',
    '>For Rent</option>': '>للايجار</option>',
    '>For Sale</option>': '>للبيع</option>',
    '>Beds</option>': '>أسرة</option>',
    '>Baths</option>': '>حمامات</option>',
    '>Warehouse</option>': '>مخزن</option>',
    '>Land</option>': '>قطعة ارض</option>',
    '>Commercial</option>': '>تجاري</option>',
    '>Area Size:</label>': '>المساحة:</label>',
    '>Center Cooling</span>': '>تكييف مركزي</span>',
    '>Balcony</span>': '>شرفة</span>',
    '>Pet Friendly</span>': '>يسمح بالحيوانات الأليفة</span>',
    '>Barbeque</span>': '>منطقة شواء</span>',
    '>Fire Alarm</span>': '>إنذار حريق</span>',
    '>Modern Kitchen</span>': '>مطبخ حديث</span>',
    '>Storage</span>': '>مخزن</span>',
    '>Dryer</span>': '>مجفف</span>',
    '>Heating</span>': '>تدفئة</span>',
    '>Pool</span>': '>مسبح</span>',
    '>Laundry</span>': '>غسيل</span>',
    '>Sauna</span>': '>ساونا</span>',
    '>Gym</span>': '>نادي رياضي</span>',
    '>Elevator</span>': '>مصعد</span>',
    '>Dish Washer</span>': '>غسالة صحون</span>',
    '>Emergency Exit</span>': '>مخرج طوارئ</span>',
    '>More options</a>': '>خيارات إضافية</a>',
    '>Less options</a>': '>خيارات أقل</a>',
    
    # Profile & Social Pages
    '>Edit Profile</a>': '>تعديل الملف الشخصي</a>',
    '>Social Profiles</a>': '>الملف الاجتماعي</a>',
    '>Social Profiles<h4>': '>الملف الاجتماعي<h4>',
    '>My Properties</a>': '>عقاراتي</a>',
    '>Favorite Properties</a>': '>المفضلة</a>',
    '>Add Property</a>': '>أضف عقار</a>',
    '>Personal Details<h4>': '>البيانات الشخصية<h4>',
    '>First Name</label>': '>الاسم الأول</label>',
    '>Last Name</label>': '>اسم العائلة</label>',
    '>Email Address</label>': '>البريد الإلكتروني</label>',
    '>Phone</label>': '>الهاتف</label>',
    '>About Me</label>': '>نبذة عني</label>',
    '>Change Password<h4>': '>تغيير كلمة المرور</label>',
    '>password</label>': '>كلمة المرور</label>',
    '>confirm password</label>': '>تأكيد كلمة المرور</label>',
    'value="Save Edits"': 'value="حفظ التعديلات"',
    '>Profile Picture<h4>': '>صورة الملف الشخصي<h4>',
    '>Upload': '>رفع',
    '>Delete</a>': '>حذف</a>',
    '>Facebook URL">': '>رابط فيسبوك">',
    '>@Username">': '>اسم المستخدم@">',
    '>google-plus URL">': '>رابط جوجل بلس">',
    '>LinkedIn URL">': '>رابط لينكد إن">',
    '>Instagram</label>': '>انستغرام</label>',
    '>Pinterest</label>': '>بينتيريست</label>',
    '>user Profile<h1>': '>ملف المستخدم<h1>',
    '>user Profile</li>': '>ملف المستخدم</li>',
    '>Social Profile<h1>': '>الملف الاجتماعي<h1>',
    '>Social Profile</li>': '>الملف الاجتماعي</li>',

    # Add Property Page
    '>Add Property</h1>': '>أضف عقار</h1>',
    '>Add Property</li>': '>أضف عقار</li>',
    '>Property Description<h4>': '>وصف العقار<h4>',
    '>Property Title*</label>': '>عنوان العقار*</label>',
    '>Property Description*</label>': '>وصف العقار*</label>',
    '>Type</label>': '>النوع</label>',
    '>Status</label>': '>الحالة</label>',
    '>Sale</option>': '>بيع</option>',
    '>Rent</option>': '>إيجار</option>',
    '>Location</label>': '>الموقع</label>',
    '>Bedrooms</label>': '>غرف النوم</label>',
    '>Bathrooms</label>': '>الحمامات</label>',
    '>Floors</label>': '>الطوابق</label>',
    '>Garages</label>': '>الكراجات</label>',
    '>Area</label>': '>المساحة</label>',
    '>Size</label>': '>الحجم</label>',
    '>Sale or Rent Price*</label>': '>سعر البيع أو الإيجار*</label>',
    '>Before Price Label</label>': '>تسمية السعر (سابقاً)</label>',
    '>After Price Label</label>': '>تسمية السعر (لاحقاً)</label>',
    '>Property ID*</label>': '>رقم العقار*</label>',
    '>Video URL</label>': '>رابط الفيديو</label>',
    '>Property Features<h4>': '>ميزات العقار<h4>',
    '>Property Gallery<h4>': '>معرض صور العقار<h4>',
    '>Property Location<h4>': '>موقع العقار<h4>',
    '>Address*</label>': '>العنوان*</label>',
    '>Country</label>': '>الدولة</label>',
    '>City</label>': '>المدينة</label>',
    '>State</label>': '>المنطقة/المحافظة</label>',
    '>Zip/Postal Code</label>': '>الرمز البريدي</label>',
    '>Neighborhood</label>': '>الحي</label>',
    '>Select property country</option>': '>اختر الدولة</option>',
    'placeholder="Enter your property address"': 'placeholder="أدخل عنوان عقارك"',
    'placeholder="Youtube, Vimeo, Dailymotion, etc.."': 'placeholder="يوتيوب، فيميو، ديلي موشن، إلخ.."',
    'placeholder="ex: start from"': 'placeholder="مثال: يبدأ من"',
    'placeholder="ex: monthly"': 'placeholder="مثال: شهرياً"',
    'placeholder="sq ft"': 'placeholder="قدم مربع"',

    # Addresses & Maps (Inline Scripts)
    'address: "121 King St,Melbourne, Australia"': 'address: "121 شارع كينغ، ملبورن، أستراليا"',
    'address: "Melbourne, Australia"': 'address: "ملبورن، أستراليا"',
    '86 Petersham town, New South Wales Wardll Street, Australia PA 6550': '86 مدينة بيترشام، نيو ساوث ويلز، شارع واردل، أستراليا PA 6550',
    '86 Petersham town, Wardll street Australia PA 6550.': '86 مدينة بيترشام، شارع واردل، أستراليا PA 6550.',


    # Agent Profile & Contact
    '>Buying Agent': '>وكيل عقاري',
    '>Selling Agent': '>وكيل بيع',
    '>Real Estate Broker': '>وسيط عقاري',
    '>Company</h5>': '>الشركة</h5>',
    '>Learn More</h5>': '>روابط هامة</h5>',
    '>Agent Profile<h1>': '>الملف الشخصي للوكيل<h1>',
    '>Agent Profile</li>': '>الملف الشخصي للوكيل</li>',
    '>Phone:</span>': '>الهاتف:</span>',
    '>Mobile:</span>': '>الجوال:</span>',
    '>Fax:</span>': '>الفاكس:</span>',
    '>Website:</span>': '>الموقع:</span>',
    '>Email:</span>': '>البريد:</span>',
    '>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercit.': 
    '>وكيل عقاري ذو خبرة واسعة في السوق المحلي، ملتزم بتقديم أفضل الخدمات والاستشارات العقارية للعملاء لضمان تجربة بيع وشراء سلسة وناجحة.',

    # Property Listings & Details
    '>Beds:</span>': '>غرف:</span>',
    '>Baths:</span>': '>حمامات:</span>',
    '>Area:</span>': '>المساحة:</span>',
    '>sq ft</span>': '>قدم مربع</span>',
    '>Garages:</span>': '>كراجات:</span>',
    '>Apartment in': '>شقة في',
    '>Villa in': '>فيلا في',
    '>House in': '>منزل في',
    '>Find Your Favorite Property<h1>': '>اعثر على عقارك المفضل</h1>',
    
    # Locations (Dropdowns) - Hierarchical Search Request
    '>Any Location</option>': '>الدولة / المدينة / المنطقة / الحي</option>',
    '>Alabama</option>': '>الدولة</option>',
    '>Alaska</option>': '>المدينة</option>',
    '>California</option>': '>المحلية / المحليات</option>',
    '>Florida</option>': '>الحي / المنطقة</option>',
    '>Mississippi</option>': '>الموقع المختار</option>',
    '>Oregon</option>': '>كل المواقع</option>',

    # Simple Steps Section (Domain Specific Content)
    '>Simple Steps</h2>': '>خطوات بسيطة</h2>',
    '>Search For Real Estates</h3>': '>البحث عن العقارات</h3>',
    '>Select Your Favorite</h3>': '>خيارك المفضل</h3>',
    '>Take Your Key</h3>': '>استلم مفتاحك</h3>',
    '>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>': 
    '>نحن نسهل عليك عملية البحث والاختيار والتعاقد لتصل إلى منزلك الجديد بأسرع وقت وأقل جهد ممكن.</p>',
    
    # Specific Step Descriptions
    '<h3>Search For Real Estates</h3>\n                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>':
    '<h3>البحث عن العقارات</h3>\n                                <p>ابدأ بالبحث في مجموعتنا الواسعة من العقارات المتميزة التي تناسب احتياجاتك وميزانيتك من خلال فلاتر البحث المتقدمة.</p>',
    
    '<h3>Select Your Favorite</h3>\n                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>':
    '<h3>خيارك المفضل</h3>\n                                <p>تصفح التفاصيل الكاملة والصور وقم بمقارنة الخيارات المختلفة للعثور على العقار المثالي الذي يلبي تطلعاتك.</p>',
    
    '<h3>Take Your Key</h3>\n                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>':
    '<h3>استلم مفتاحك</h3>\n                                <p>اتمم إجراءات التعاقد بكل سهولة ويسر مع فريقنا المتخصص، وانتقل إلى منزلك الجديد لتبدأ حياة جديدة ومستقرة.</p>',


    # Generic Fallbacks (if exact match fails)
    '>Duis aute irure dolor in reprehed in volupted velit esse dolore': '>نخبة من أفضل العقارات والخدمات المتميزة التي تلبي جميع تطلعاتكم العقارية.',

    # Specific Section Placeholders - index.html
    '>Latest Properties</h2>\n                            <p class="heading--desc">Discover the latest premium properties available for sale or rent in carefully selected strategic locations.</p>':
    '>أحدث العقارات</h2>\n                            <p class="heading--desc">اكتشف أحدث العقارات المتميزة المتوفرة للبيع أو الإيجار في أفضل المواقع الاستراتيجية المختارة بعناية.</p>',

    '>Simple Steps<h2>\n                            <p class="heading--desc">We provide you with an integrated real estate experience and clear steps that start from searching and end with receiving the key to your new home.</p>':
    '>خطوات بسيطة</h2>\n                            <p class="heading--desc">نقدم لك تجربة عقارية متكاملة وخطوات واضحة تبدأ من البحث وتنتهي باستلام مفتاح منزلك الجديد بكل يسر.</p>',

    '>Property By City<h2>\n                            <p class="heading--desc">Browse available properties in the most prestigious cities and regions, where we provide you with a comprehensive and diverse list.</p>':
    '>عقارات حسب المدينة</h2>\n                            <p class="heading--desc">تصفح العقارات المتاحة في أرقى المدن والمناطق، حيث نوفر لك قائمة شاملة ومتنوعة تلبي تطلعاتك الاستثمارية والسكنية.</p>',

    '>Trusted Agents<h2>\n                            <p class="heading--desc">A selection of the best real estate agents with high experience and competence to help you make the best real estate decisions.</p>':
    '>وكلاء موثوقون</h2>\n                            <p class="heading--desc">نخبة من أفضل الوكلاء العقاريين ذوي الخبرة والكفاءة العالية لمساعدتك في اتخاذ أفضل القرارات العقارية.</p>',

    # Agent List Placeholders
    '>A professional real estate agent committed to providing the best consulting services to ensure a successful experience for all clients.</p>':
    '>وكيل عقاري محترف ملتزم بتقديم أفضل الخدمات الاستشارية لضمان تجربة ناجحة لجميع العملاء.</p>',

    # Simple Steps Panel Descriptions
    '<h3>Search For Real Estates</h3>\n                                <p>Start searching through our wide collection of premium properties that suit your needs and budget through advanced search filters.</p>':
    '<h3>البحث عن العقارات</h3>\n                                <p>ابدأ بالبحث في مجموعتنا الواسعة من العقارات المتميزة التي تناسب احتياجاتك وميزانيتك من خلال فلاتر البحث المتقدمة.</p>',

    '<h3>Select Your Favorite</h3>\n                                <p>Browse full details and photos, and compare different options to find the perfect property that meets your expectations.</p>':
    '<h3>خيارك المفضل</h3>\n                                <p>تصفح التفاصيل الكاملة والصور وقم بمقارنة الخيارات المختلفة للعثور على العقار المثالي الذي يلبي تطلعاتك.</p>',

    '<h3>Take Your Key</h3>\n                                <p>Complete the contracting procedures easily with our specialized team, and move to your new home to start a new and stable life.</p>':
    '<h3>استلم مفتاحك</h3>\n                                <p>اتمم إجراءات التعاقد بكل سهولة ويسر مع فريقنا المتخصص، وانتقل إلى منزلك الجديد لتبدأ حياة جديدة ومستقرة.</p>',

    # Location Dropdown
    '>Country / City / Locality / Neighborhood</option>': '>الدولة / المدينة / المنطقة / الحي</option>',
    '>State / City / Area / District</option>': '>المحافظة / المدينة / المنطقة / الحي</option>',
    '>Any Country</option>': '>كل الدول</option>',
    '>Any State</option>': '>كل الولايات</option>',
    '>Any City</option>': '>كل المدن</option>',
    '>Any Locality</option>': '>كل المناطق</option>',
    '>Any Neighborhood</option>': '>كل الأحياء</option>',
    '&copy; 2024 Lalan Real Estate, All Rights Reserved.': '&copy; 2024 لالان العقارية، جميع الحقوق محفوظة.',


    # Missing Page Titles
    '>About Me<h1>': '>نبذة عني<h1>',
    '>About Me</a>': '>نبذة عني</a>',
    '>Properties List Split</a>': '>قائمة العقارات</a>',
    '>properties list split</a>': '>قائمة العقارات</a>',
    '>Properties List</a>': '>قائمة العقارات</a>',
    '>Properties Grid</a>': '>شبكة العقارات</a>',
    '>Properties Grid Split</a>': '>شبكة العقارات</a>',
    '>Single Gallery</a>': '>معرض الصور</a>',
    '>Single Slider</a>': '>شريط الصور</a>',
    '>single gallery</a>': '>معرض الصور</a>',
    '>single slider</a>': '>شريط الصور</a>',

    # Common Footer/Widgets
    '>newsletter</h5>': '>النشرة البريدية<h5>',
    '>Get In Touch<h6>': '>ابق على تواصل<h6>',
    '>Privacy</a>': '>الخصوصية</a>',
    '>Account</a>': '>الحساب</a>',
    '>Career</a>': '>وظائف</a>',
    '>Services</a>': '>خدمات</a>',

    # Hero / Search
    '>Find Your Favorite Property<h1>': '>اعثر على عقارك المفضل</h1>',
    '>Any Location</option>': '>أي موقع</option>',
    '>Any Type</option>': '>أي نوع</option>',
    '>Any Status</option>': '>أي حالة</option>',
    'value="Search"': 'value="بحث"',
    '>More options</a>': '>خيارات إضافية</a>',
    '>Price Range: </label>': '>نطاق السعر: </label>',
    
    # Footer / Misc
    '>Quick Links</h3>': '>روابط سريعة</h3>',
    '>Contact Us</h3>': '>اتصل بنا</h3>',
    '>Follow Us</h3>': '>تابعنا</h3>',
    '>Latest Properties</h2>': '>أحدث العقارات</h2>',
    '>Simple Steps<h2>': '>خطوات بسيطة</h2>',
    '>Trusted Agents<h2>': '>وكلاء موثوقون</h2>',
    '>Property By City<h2>': '>عقارات حسب المدينة</h2>',
    
    # Common words in context
    '>Beds:</span>': '>غرف:</span>',
    '>Baths:</span>': '>حمامات:</span>',
    '>Area:</span>': '>مساحة:</span>',
    '>For Sale</span>': '>للبيع</span>',
    '>For Rent</span>': '>للإيجار</span>',
    '>month</span>': '>شهر</span>',

    # FAQ Page
    '>Find answers to the most common questions about buying, selling, and renting properties with our expert team.</p>': '>ابحث عن إجابات لأكثر الأسئلة شيوعاً حول شراء وبيع وتأجير العقارات مع فريق الخبراء لدينا.</p>',
    '<h3>What is a real estate broker?</h3>': '<h3>ما هو الوسيط العقاري؟</h3>',
    '>A real estate broker is a licensed professional who represents sellers or buyers of real estate. While a broker can work independently, they often lead a team of agents to help clients navigate the complexities of property transactions.</p>': '>الوسيط العقاري هو متخصص مرخص يمثل البائعين أو المشترين للعقارات. بينما يمكن للوسيط العمل بشكل مستقل، فإنهم غالباً ما يقودون فريقاً من الوكلاء لمساعدة العملاء في التنقل عبر تعقيدات المعاملات العقارية.</p>',
    '<h3>Why should I use a real estate salesperson?</h3>': '<h3>لماذا يجب علي استخدام مندوب مبيعات عقاري؟</h3>',
    '>Working with a professional salesperson provides you with expert market analysis, negotiation skills, and access to a wider network of listings, ensuring you get the best possible deal while saving time and effort.</p>': '>العمل مع مندوب مبيعات محترف يوفر لك تحليلاً خبيراً للسوق، ومهارات التفاوض، والوصول إلى شبكة أوسع من القوائم، مما يضمن حصولك على أفضل صفقة ممكنة مع توفير الوقت والجهد.</p>',
    '<h3>What if my offer is rejected?</h3>': '<h3>ماذا لو رُفض عرضي؟</h3>',
    '>If your offer is rejected, don’t be discouraged. We will analyze the feedback, adjust our strategy, and continue searching for the right property that meets your needs and budget.</p>': '>إذا تم رفض عرضك، فلا تحبط. سنقوم بتحليل الملاحظات، وتعديل استراتيجيتنا، ومواصلة البحث عن العقار المناسب الذي يلبي احتياجاتك وميزانيتك.</p>',
    '<h3>Should I buy or continue to rent?</h3>': '<h3>هل يجب علي الشراء أم الاستمرار في الاستئجار؟</h3>',
    '>The decision depends on your financial goals and lifestyle. Buying builds equity and provides stability, while renting offers flexibility. We can provide a detailed comparison to help you make the best choice for your future.</p>': '>يعتمد القرار على أهدافك المالية ونمط حياتك. الشراء يبني رأس المال ويوفر الاستقرار، بينما يوفر الاستئجار المرونة. يمكننا تقديم مقارنة مفصلة لمساعدتك في اتخاذ الخيار الأفضل لمستقبلك.</p>',

    # About Us Page Features (New)
    '>We use high-quality photography and virtual tours to showcase your property\'s best features and attract the right buyers.</p>': '>نستخدم تصويراً فوتوغرافياً عالي الجودة وجولات افتراضية لعرض أفضل ميزات عقارك وجذب المشترين المناسبين.</p>',
    '>Whether you\'re looking to rent out or sell your property, we provide expert guidance to maximize your returns.</p>': '>سواء كنت تبحث عن تأجير أو بيع عقارك، فنحن نقدم توجيهات خبيرة لتحقيق أقصى قدر من عوائدك.</p>',
    '>Our specialized team handles the complexities of property exchange, ensuring a fair and smooth transition for all parties.</p>': '>يتعامل فريقنا المتخصص مع تعقيدات تبادل العقارات، مما يضمن انتقالاً عادلاً وسلساً لجميع الأطراف.</p>',
    '>We help you find the perfect property that fits your lifestyle and investment goals, guiding you through every step of the purchase.</p>': '>نساعدك في العثور على العقار المثالي الذي يناسب نمط حياتك وأهدافك الاستثمارية، ونرشدك خلال كل خطوة من خطوات الشراء.</p>',
    '>Our agents are highly professional and dedicated to helping you find your dream home or sell your property for the best price.</p>': '>وكلاؤنا محترفون للغاية ومكرسون لمساعدتك في العثور على منزل أحلامك أو بيع عقارك بأفضل سعر.',
    '>A committed real estate professional with extensive knowledge of the local market, dedicated to providing exceptional service.</p>': '>محترف عقاري ملتزم يتمتع بمعرفة واسعة بالسوق المحلي، ومكرس لتقديم خدمة استثنائية.</p>',

    # Home Pages (Map/Property)
    '>Explore our newest property listings, from luxury villas to modern apartments, and find your perfect home today.</p>': '>استكشف أحدث قوائم العقارات لدينا، من الفيلات الفاخرة إلى الشقق الحديثة، واعثر على منزلك المثالي اليوم.</p>',
    '>Follow our straightforward process to find, select, and secure your next premium property with ease.</p>': '>اتبع عمليتنا المباشرة للعثور على عقارك المميز القادم واختياره وتأمينه بكل سهولة.</p>',
    '>Discover a wide range of properties tailored to your needs using our advanced search tools and expert local knowledge.</p>': '>اكتشف مجموعة واسعة من العقارات المصممة لتلبية احتياجاتك باستخدام أدوات البحث المتقدمة لدينا وخبرتنا المحلية الواسعة.</p>',
    '>Compare listings and choose the property that best fits your lifestyle, investment goals, and family needs.</p>': '>قارن بين القوائم واختر العقار الذي يناسب نمط حياتك وأهدافك الاستثمارية واحتياجات عائلتك بشكل أفضل.</p>',
    '>Experience a seamless closing process and receive the keys to your new home with our professional guidance.</p>': '>استمتع بعملية إغلاق سلسة واستلم مفاتيح منزلك الجديد مع توجيهاتنا المهنية.</p>',
    '>Find the most exclusive real estate opportunities in top-tier cities, carefully selected for quality and value.</p>': '>اعثر على أكثر الفرص العقارية حصرية في المدن الكبرى، والتي تم اختيارها بعناية لضمان الجودة والقيمة.</p>',
}

TR_TRANSLATIONS = {
    # Navigation
    '>home</a>': '>Anasayfa</a>',
    '>Home</a>': '>Anasayfa</a>',
    '>Pages</a>': '>Sayfalar</a>',
    '>Page</a>': '>Sayfa</a>',
    '>Profile</a>': '>Profil</a>',
    '>Properties</a>': '>İlanlar</a>',
    '>contact</a>': '>İletişim</a>',
    '>Contact</a>': '>İletişim</a>',
    
    # Submenus
    '>home search</a>': '>Ev Ara</a>',
    '>home map</a>': '>Harita</a>',
    '>home property</a>': '>Emlak</a>',
    '>home splash</a>': '>Karşılama</a>',
    '>agents</a>': '>Emlakçılar</a>',
    '>All Agents</a>': '>Tüm Emlakçılar</a>',
    '>agent profile</a>': '>Emlakçı Profili</a>',
    '>agencies</a>': '>Acenteler</a>',
    '>all agencies</a>': '>Tüm Acenteler</a>',
    '>agency profile</a>': '>Acente Profili</a>',
    '>blog</a>': '>Blog</a>',
    '>blog Grid</a>': '>Blog Listesi</a>',
    '>blog single</a>': '>Blog Detay</a>',
    '>page about</a>': '>Hakkımızda</a>',
    '>page contact</a>': '>İletişim</a>',
    '>page FAQ</a>': '>SSS</a>',
    '>user profile</a>': '>Kullanıcı Profili</a>',
    '>social profile</a>': '>Sosyal Profil</a>',
    '>my properties</a>': '>İlanlarım</a>',
    '>favourite properties</a>': '>Favoriler</a>',
    '>add property</a>': '>İlan Ver</a>',
    '>Properties grid</a>': '>İlanlar (Izgara)</a>',
    '>properties list</a>': '>İlanlar (Liste)</a>',
    '>properties single</a>': '>İlan Detayı</a>',
    
    # About Us Page
    '>About</h1>': '>Hakkımızda</h1>',
    '>About Us</a>': '>Hakkımızda</a>',
    '>We Provide Lovable Experiment in the Real Estate Field</h2>': '>Gayrimenkul Alanında Sevilen Deneyimler Sunuyoruz</h2>',
    '>Our Vision</h3>': '>Vizyonumuz</h3>',
    '>Our Goal</h3>': '>Hedefimiz</h3>',
    '>What We Provide?</h2>': '>Ne Sunuyoruz?</h2>',
    '>Presenting Your Property</h3>': '>Mülkünü Sun</h3>',
    '>Renting or Selling</h3>': '>Kiralama veya Satış</h3>',
    '>Property Exchange</h3>': '>Mülk Takası</h3>',
    '>Buying a Property</h3>': '>Mülk Satın Alma</h3>',
    '>About</li>': '>Hakkımızda</li>',
    
    # Contact Page
    '>Contact</h1>': '>İletişim</h1>',
    '>Contact</li>': '>İletişim</li>',
    '>Get In Touch</h2>': '>İletişime Geçin</h2>',
    '>Address</h3>': '>Adres</h3>',
    '>Phone:</h3>': '>Telefon:</h3>',
    '>Email:</h3>': '>E-posta:</h3>',
    '>Your Name*</label>': '>Adınız*</label>',
    '>Email Address*</label>': '>E-posta Adresi*</label>',
    '>Phone Number</label>': '>Telefon Numarası</label>',
    '>Message*</label>': '>Mesaj*</label>',
    'value="Send Message"': 'value="Mesaj Gönder"',
    '>Phone Number</label>': '>Telefon Numarası</label>',
    '>Message*</label>': '>Mesaj*</label>',
    'value="Send Message"': 'value="Mesaj Gönder"',
    'placeholder="(optional)"': 'placeholder="(isteğe bağlı)"',

    # Placeholders / Lorem Ipsum - Domain Specific
    '>What We Provide?</h2>\n                            <p class="heading--desc">Duis aute irure dolor in reprehed in volupted velit esse dolore</p>': 
    '>Ne Sunuyoruz?</h2>\n                            <p class="heading--desc">Hayalinizdeki evi bulmanız veya başarılı bir yatırım yapmanız için tüm ihtiyaçlarınızı karşılayacak kapsamlı gayrimenkul hizmetleri sunuyoruz.</p>',

    '<h3>Presenting Your Property</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>Mülkünü Sun</h3>\n                                <p>Mülkünüzü potansiyel alıcılara hızlı ve verimli bir şekilde ulaştırmak için en iyi şekilde sunmanıza yardımcı oluyor, pazarlama danışmanlığı sağlıyoruz.</p>',

    '<h3>Renting or Selling</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>Kiralama veya Satış</h3>\n                                <p>Mülkünüzü satmak veya kiralamak istiyorsanız, en kısa sürede en iyi getiriyi sağlamak için size hukuki ve pazarlama desteği sağlıyoruz.</p>',

    '<h3>Property Exchange</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>Mülk Takası</h3>\n                                <p>Mülk takası için esnek seçenekler sunarak, yeni evinize taşınmanızı veya gayrimenkul yatırımlarınızı çeşitlendirmenizi kolaylaştırıyoruz.</p>',

    '<h3>Buying a Property</h3>\n                                <p>Duis sed odio sit amet nibh vtate cursusa sit amet mauris morbi accum ipsum velit nam nec tellus viele a odio tincidet auctor ornare odio. Sede non mauris vitae erat conquat.</p>':
    '<h3>Mülk Satın Alma</h3>\n                                <p>Bütçenize ve ihtiyaçlarınıza uygun geniş gayrimenkul seçeneklerini keşfedin, her adımda size yardımcı olacak uzman ekibimizle yanınızdayız.</p>',

    # Mixed Language Fixes (Header, Footer, CTA, Modal)
    '>add property</a>': '> İlan Ekle</a>',
    '> add property</a>': '> İlan Ekle</a>',
    '>About us</a>': '>Hakkımızda</a>',
    '>Career</a>': '>Kariyer</a>',
    '>Services</a>': '>Hizmetler</a>',
    '>Privacy</a>': '>Gizlilik</a>',
    '>Terms & Conditions</a>': '>Şartlar ve Koşullar</a>',
    '>Account</a>': '>Hesap</a>',
    '>FAQ</a>': '>SSS</a>',
    '>Join our professional team & agents to start selling your house</h3>': '>Profesyonel ekibimize katılın ve evinizi satmaya başlayın</h3>',
    '>86 Petersham town, New South Wales Wardll Street, Australia PA 6550</p>': '>86 Petersham Town, New South Wales Wardll Street, Avustralya PA 6550</p>',

    # FAQ Page
    '>Asked Questions</h2>': '>Sıkça Sorulan Sorular</h2>',
    '>Find answers to the most common questions about buying, selling, and renting properties with our expert team.</p>': '>Uzman ekibimizle gayrimenkul alım, satım ve kiralama konusundaki en yaygın sorulara yanıt bulun.</p>',
    '>What is a real estate broker?</a>': '>Emlak komisyoncusu nedir?</a>',
    '<p>A real estate broker is a professional who has completed advanced training and passed a state-licensing exam. They can work independently or hire other agents to work for them.</p>': '<p>Emlak komisyoncusu, ileri düzey eğitim almış ve devlet lisans sınavını geçmiş bir profesyoneldir. Bağımsız çalışabilir veya kendileri için çalışacak başka acenteler kiralayabilirler.</p>',
    '>Why should I use a real estate salesperson?</a>': '>Neden bir emlak satış elemanı kullanmalıyım?</a>',
    'A professional agent provides expert market knowledge, handles complex paperwork, and negotiates the best price on your behalf, ensuring a smooth and legally sound transaction.': 'Profesyonel bir temsilci, uzman piyasa bilgisi sağlar, karmaşık evrak işlerini halleder ve sizin adınıza en iyi fiyatı pazarlık ederek sorunsuz ve yasal olarak sağlam bir işlem sağlar.',
    '>What if my offer is rejected?</a>': '>Ya teklifim reddedilirse?</a>',
    'If an offer is rejected, your agent will help you understand the reasons and guide you through making a counter-offer or searching for a better-suited property.': 'Bir teklif reddedilirse, temsilciniz nedenleri anlamanıza yardımcı olacak ve karşı teklif yapmanız veya daha uygun bir mülk aramanız konusunda size rehberlik edecektir.',
    '>Should I buy or continue to rent?</a>': '>Satın almalı mıyım yoksa kiralamaya devam mı etmeliyim?</a>',
    'Buying a property is along-term investment that builds equity and provides stability. Our experts can help you analyze the market to decide if now is the right time for you to buy.': 'Bir mülk satın almak, özsermaye oluşturan ve istikrar sağlayan uzun vadeli bir yatırımdır. Uzmanlarımız, şimdi satın almanız için doğru zaman olup olmadığına karar vermeniz için piyasayı analiz etmenize yardımcı olabilir.',
    
    # Missing Menu Items (Lowercase)
    '>properties grid</a>': '>İlanlar (Izgara)</a>',
    '>properties grid split</a>': '>İlanlar (Izgara/Bölünmüş)</a>',
    '>properties list</a>': '>İlanlar (Liste)</a>',
    '>properties list split</a>': '>İlanlar (Liste/Bölünmüş)</a>',
    '>single gallery</a>': '>Galeri Görünümü</a>',
    '>single slider</a>': '>Slayt Görünümü</a>',
    '>agent profile</a>': '>Temsilci Profili</a>',
    '>agency profile</a>': '>Acente Profili</a>',
    '>blog Grid</a>': '>Blog Izgara</a>',
    '>blog Grid Right </a>': '>Blog Izgara Sağ</a>',
    '>blog Grid Left </a>': '>Blog Izgara Sol</a>',
    '>blog single</a>': '>Blog Tekil</a>',
    '>page about</a>': '>Hakkımızda Sayfası</a>',
    '>page contact</a>': '>İletişim Sayfası</a>',
    '>page FAQ</a>': '>SSS Sayfası</a>',
    '>page 404</a>': '>404 Sayfası</a>',
    '>user profile</a>': '>Kullanıcı Profili</a>',
    '>social profile</a>': '>Sosyal Profil</a>',
    '>my properties</a>': '>Emlaklarım</a>',
    '>agent profile</a>': '>Temsilci Profili</a>',
    '>agency profile</a>': '>Acente Profili</a>',
    '>blog Grid</a>': '>Blog Ağı</a>',
    '>blog Grid Right </a>': '>Blog Ağı</a>',
    '>blog Grid Left </a>': '>Blog Ağı</a>',
    '>blog single</a>': '>Blog Tekil</a>',
    '>page about</a>': '>Hakkımızda</a>',
    '>page contact</a>': '>İletişim</a>',
    '>page FAQ</a>': '>SSS</a>',
    '>page 404</a>': '>404 Sayfası</a>',
    '>user profile</a>': '>Kullanıcı Profili</a>',
    '>social profile</a>': '>Sosyal Profil</a>',
    '>my properties</a>': '>Emlaklarım</a>',
    '>favourite properties</a>': '>Favoriler</a>',

    # Property By City - Turkish
    'Los Angeles': 'Antalya',
    'Los Angeles, CA': 'Antalya',
    'New York': 'İstanbul',
    'Chicago': 'Ankara',
    'Manhatten': 'İzmir',
    '16 Properties': '16 İlan',
    '14 Properties': '14 İlan',
    '18 Properties': '18 İlan',
    '10 Properties': '10 İlan',
    'Property By City': 'Şehre Göre Emlak',
    'Find the most exclusive real estate opportunities in top-tier cities, carefully selected for quality and value.': 'En kaliteli şehirlerdeki en özel gayrimenkul fırsatlarını keşfedin, kalite ve değer için özenle seçildi.',

    # My Properties Page
    '>my properties</h1>': '>Emlaklarım</h1>',
    '>my properties</li>': '>Emlaklarım</li>',
    '>My Properties</a>': '>Emlaklarım</a>',
    '>House in Sheffleld Ave</a>': '>Sheffleld Ave\'de Ev</a>',
    '2003 Sheffield Ave, Anderson, IN 46011': '2003 Sheffield Ave, Antalya, 46011',
    '>2750 House in Urban St.</a>': '>Urban St.\'de 2750 Ev</a>',
    '2750 Urban Street Dr, Anderson, IN 46011': '2750 Urban Street Dr, Antalya, 46011',
    '>Apartment For Rent</a>': '>Kiralık Daire</a>',
    '1609 N Richmond St, Chicago, IL 60647': '1609 N Richmond St, Ankara, 60647',
    '>House in Miami Town</a>': '>Miami Town\'da Ev</a>',
    '415 E North Water, Miami 60611': '415 E North Water, İzmir, 60611',
    '>Edit</a>': '>Düzenle</a>',
    '>Edit</a>': '>Düzenle</a>',
    ' sq ft</span>': ' ft²</span>',

    # Page Headers & Breadcrumbs (General)
    '>Blog<h1>': '>Blog<h1>',
    '>Blog</li>': '>Blog</li>',
    '>Agents<h1>': '>Temsilciler<h1>',
    '>Agents</li>': '>Temsilciler</li>',
    '>Agency List<h1>': '>Acente Listesi<h1>',
    '>Agency List</li>': '>Acente Listesi</li>',
    '>Property Single<h1>': '>Emlak Detayı<h1>',
    '>Property Single</li>': '>Emlak Detayı</li>',
    '>Add Property<h1>': '>Emlak Ekle<h1>',
    '>Add Property</li>': '>Emlak Ekle</li>',

    # Blog Details
    '>Read More</a>': '>Devamını Oku</a>',
    '>Comments</a>': '>Yorumlar</a>',
    '>Leave a Comment</a>': '>Yorum Yap</a>',
    '>Recent Posts<h5>': '>Son Gönderiler<h5>',
    '>Categories<h5>': '>Kategoriler<h5>',
    '>Archives<h5>': '>Arşivler<h5>',
    '>Tags<h5>': '>Etiketler<h5>',
    '10 Quick Tips About Real Estate': 'Gayrimenkul Hakkında 10 Hızlı İpucu',
    ' Skillfully plan your homeâ\x80\x99s design': ' Evinizin tasarımını ustaca planlayın',
    'Real Estate recent news': 'Gayrimenkulden son haberler',
    'Buying a Home': 'Ev Satın Alma',
    'Selling a Home': 'Ev Satış',
    'Rental': 'Kiralama',
    'Architecture': 'Mimari',
    'Interior Design': 'İç Tasarım',
    'Modern': 'Modern',
    'Luxury': 'Lüks',
    'Studio': 'Stüdyo',
    'Apartment': 'Daire',
    'House': 'Ev',

    # Agency Profile Page
    '>Agency Profile<h1>': '>Acente Profili<h1>',
    '>Agency Profile</li>': '>Acente Profili</li>',
    '>Properties List</h2>': '>Emlak Listesi</h2>',
    '>Contact Us</h2>': '>İletişim</h2>',
    '>Our Agents</h2>': '>Acentelerimiz</h2>',
    'A committed real estate professional with extensive knowledge of the local': 'Yerel pazar hakkında geniş bilgiye sahip, kendini işine adamış gayrimenkul profesyoneli,',
    'market, dedicated to providing exceptional service and achieving the best': 'olağanüstü hizmet sunmaya ve her müşteri için en iyi sonuçları elde etmeye',
    'results for every client.': 'odaklanmıştır.',

    # Login Modal Specifics
    '>login</a>': '>Giriş</a>',
    '>signup</a>': '>Kayıt</a>',
    '<span>or</span>': '<span>veya</span>',
    '<span>Remember Me</span>': '<span>Beni Hatırla</span>',
    '<span>I agree with all <a href="#">Terms & Conditions</a></span>': '<span>Tüm <a href="#">Şartlar ve Koşullar</a>ı kabul ediyorum</span>',
    'placeholder="Email Address"': 'placeholder="E-posta Adresi"',
    'placeholder="Password"': 'placeholder="Şifre"',
    'placeholder="Full Name"': 'placeholder="Ad Soyad"',
    'value="Sign In"': 'value="Giriş Yap"',
    'value="Register"': 'value="Kayıt Ol"',
    'Login with': 'ile Giriş Yap',
    'Register with': 'ile Kayıt Ol',
    'Forget your': 'Şifrenizi mi',
    '>Login</a>': '>Giriş</a>',

    # Search & Filter Options
    '>Any Location</option>': '>Herhangi Bir Konum</option>',
    '>Any Type</option>': '>Herhangi Bir Tür</option>',
    '>Any Status</option>': '>Herhangi Bir Durum</option>',
    '>Apartment</option>': '>Daire</option>',
    '>House</option>': '>Ev</option>',
    '>Office</option>': '>Ofis</option>',
    '>Villa</option>': '>Villa</option>',
    
    # Property Single Page Headers & Sections
    '>Single Property</h1>': '>Emlak Detayı</h1>',
    '>Single Property</li>': '>Emlak Detayı</li>',
    '>Gallery</h2>': '>Galeri</h2>',
    '>Description</h2>': '>Açıklama</h2>',
    '>Features</h2>': '>Özellikler</h2>',
    '>Location</h2>': '>Konum</h2>',
    '>Floor Plans</h2>': '>Kat Planları</h2>',
    '>Video</h2>': '>Video</h2>',
    '>Reviews</h2>': '>Yorumlar</h2>',
    '>Leave a Review</h2>': '>Yorum Yap</h2>',
    '>About Agent</h5>': '>Temsilci Hakkında</h5>',
    '>Request a Showing</h5>': '>Gösterim İste</h5>',
    '>Featured Properties</h5>': '>Öne Çıkan Emlaklar</h5>',
    '>Send Request': '>İstek Gönder',

    # Homepage Mixed Content
    '>Find Your Favorite Property</h1>': '>Favori Emlakınızı Bulun</h1>',
    'We provide you with an integrated real estate experience and clear': 'Size entegre bir emlak deneyimi ve net adımlar sunuyoruz',
    'steps that start from searching and end with receiving the key to your new home.': 'aramadan başlayıp yeni evinizin anahtarını teslim almaya kadar.',
    'Browse available properties in the most prestigious cities and': 'En prestijli şehir ve bölgelerdeki mevcut emlakları inceleyin',
    'regions, where we provide you with a comprehensive and diverse list.': 'size kapsamlı ve çeşitli bir liste sunuyoruz.',
    '>Trusted Agents</h2>': '>Güvenilir Temsilciler</h2>',
    'A selection of the best real estate agents with high experience and': 'Yüksek deneyim ve yetkinliğe sahip en iyi emlak temsilcileri',
    'competence to help you make the best real estate decisions.': 'en iyi emlak kararlarını vermenize yardımcı olmak için.',
    
    # Agents Page
    '>Agents</h1>': '>Temsilciler</h1>',
    '>Agents</li>': '>Temsilciler</li>',
    '>Buying Agent</h6>': '>Satın Alma Temsilcisi</h6>',
    '>Selling Agent</h6>': '>Satış Temsilcisi</h6>',
    '>Real Estate Broker</h6>': '>Emlak Komisyoncusu</h6>',
    '>Realty Specialist</h6>': '>Emlak Uzmanı</h6>',
    '>Sales Assistant</h6>': '>Satış Asistanı</h6>',
    '>Assistant Broker</h6>': '>Komisyoncu Asistanı</h6>',
    'A professional real estate agent committed to providing the best consulting': 'Tüm müşteriler için başarılı bir deneyim sağlamak amacıyla',
    'services to ensure a successful experience for all clients.': 'en iyi danışmanlık hizmetlerini sunmaya kendini adamış profesyonel bir emlak temsilcisi.',
    
    # Agent/Agency Profile
    '>Agent Profile</h1>': '>Temsilci Profili</h1>',
    '>Agent Profile</li>': '>Temsilci Profili</li>',
    '>Agency Profile</h1>': '>Acente Profili</h1>',
    '>Agency Profile</li>': '>Acente Profili</li>',
    '>My Properties</h2>': '>Emlaklarım</h2>',
    '>Contact Us</h2>': '>Bize Ulaşın</h2>',
    '>Phone:</span>': '>Telefon:</span>',
    '>Email:</span>': '>E-posta:</span>',
    '>Mobile:</span>': '>Cep:</span>',
    '>Website:</span>': '>Web Sitesi:</span>',
    '>Fax:</span>': '>Faks:</span>',
    '>Email Address*</label>': '>E-posta Adresi*</label>',
    '>Phone Number</label>': '>Telefon Numarası</label>',
    '>Send Message': '>Mesaj Gönder',
    'A committed real estate professional with extensive knowledge of the local market,': 'Yerel pazar hakkında kapsamlı bilgiye sahip, kararlı bir emlak profesyoneli,',
    'dedicated to providing exceptional service and achieving the best results for every': 'olağanüstü hizmet sunmaya ve her müşteri için en iyi sonuçları elde etmeye',
    'client.': 'adanmıştır.',
    
    # Agency List
    '>Agency List</h1>': '>Acente Listesi</h1>',
    '>Agency List</li>': '>Acente Listesi</li>',
    ' Property</span>': ' Emlak</span>',
    'A leading real estate agency with over 15 years of experience in the local and': 'Yerel ve uluslararası pazarlarda 15 yılı aşkın deneyime sahip,',
    'international markets, specializing in luxury residential and commercial': 'lüks konut ve ticari emlak konusunda uzmanlaşmış lider bir emlak ajansı.',
    'properties. Our team of dedicated experts provides comprehensive consulting': 'Kendini işine adamış uzman ekibimiz, ihtiyaçlarınızı karşılayan mükemmel mülkü',
    'services to help you find the perfect property that meets your needs and': 'bulmanıza yardımcı olmak için kapsamlı danışmanlık hizmetleri sunmaktadır.',
    'investment goals.': 've yatırım hedeflerinizi karşılar.',
    'Our agency stands at the forefront of the real estate industry, offering a': 'Acentemiz, emlak sektörünün ön saflarında yer almakta olup,',
    'curated selection of residential and commercial properties. We pride ourselves': 'konut ve ticari mülklerin özenle seçilmiş bir koleksiyonunu sunmaktadır.',
    'on transparency, integrity, and a personalized approach that ensures every': 'Her müşterinin bilinçli ve başarılı bir karar vermesini sağlayan',
    'client makes an informed and successful decision.': 'şeffaflık, dürüstlük ve kişiselleştirilmiş yaklaşımımızla gurur duyuyoruz.',
    
    # All Page Headers and Breadcrumbs
    '>About</h1>': '>Hakkımızda</h1>',
    '>About</li>': '>Hakkımızda</li>',
    '>Contact</h1>': '>İletişim</h1>',
    '>Contact</li>': '>İletişim</li>',
    '>FAQ</h1>': '>SSS</h1>',
    '>FAQ</li>': '>SSS</li>',
    '>Blog</h1>': '>Blog</h1>',
    '>Blog</li>': '>Blog</li>',
    '>Blog Left Sidebar</h1>': '>Blog - Sol Kenar Çubuğu</h1>',
    '>Blog Left Sidebar</li>': '>Blog - Sol Kenar Çubuğu</li>',
    '>Blog Right Sidebar</h1>': '>Blog - Sağ Kenar Çubuğu</h1>',
    '>Blog Right Sidebar</li>': '>Blog - Sağ Kenar Çubuğu</li>',
    '>Single Property</h1>': '>Emlak Detayı</h1>',
    '>Single Property</li>': '>Emlak Detayı</li>',
    '>user Profile</h1>': '>Kullanıcı Profili</h1>',
    '>user Profile</li>': '>Kullanıcı Profili</li>',
    '>my properties</h1>': '>Emlaklarım</h1>',
    '>my properties</li>': '>Emlaklarım</li>',
    '>favourite properties</h1>': '>Favori Emlaklarım</h1>',
    '>favourite properties</li>': '>Favori Emlaklarım</li>',
    '>Social Profile</h1>': '>Sosyal Profil</h1>',
    '>Social Profile</li>': '>Sosyal Profil</li>',

    '>Get In Touch</h6>': '>İletişime Geçin</h6>',
    '>Company</h5>': '>Şirket</h5>',
    '>Learn More</h5>': '>Daha Fazla</h5>',
    '>newsletter</h5>': '>Bülten</h5>',
    '86 Petersham town, New South Wales Wardll Street, Australia PA 6550': '86 Petersham town, New South Wales Wardll Street, Avustralya PA 6550',
    '&copy; 2024 Lalan Real Estate, All Rights Reserved.': '&copy; 2024 Lalan Emlak, Tüm Hakları Saklıdır.',
    '>Any State</option>': '>Herhangi Bir Eyalet</option>',
    '>Any City</option>': '>Herhangi Bir Şehir</option>',
    '>Any Locality</option>': '>Herhangi Bir Konum</option>',
    '>Any Neighborhood</option>': '>Herhangi Bir Mahalle</option>',
    '>Any Type</option>': '>Herhangi Bir Tip</option>',
    '>Any Status</option>': '>Herhangi Bir Durum</option>',
    '>Beds</option>': '>Yatak</option>',
    '>Baths</option>': '>Banyo</option>',
    'Price Range: ': 'Fiyat Aralığı: ',
    
    # Add Property Page
    '>Add Property</li>': '>İlan Ekle</li>',
    '>Property Description</h4>': '>Emlak Açıklaması</h4>',
    '>Property Features</h4>': '>Emlak Özellikleri</h4>',
    '>Property Gallery</h4>': '>Emlak Galerisi</h4>',
    '>Property Location</h4>': '>Emlak Konumu</h4>',
    '>Property Title*</label>': '>Emlak Başlığı*</label>',
    '>Property Description*</label>': '>Emlak Açıklaması*</label>',
    '>Type</label>': '>Tip</label>',
    '>Status</label>': '>Durum</label>',
    '>Location</label>': '>Konum</label>',
    '>Bedrooms</label>': '>Yatak Odaları</label>',
    '>Bathrooms</label>': '>Banyolar</label>',
    '>Floors</label>': '>Katlar</label>',
    '>Garages</label>': '>Garajlar</label>',
    '>Area</label>': '>Alan</label>',
    '>Size</label>': '>Boyut</label>',
    '>Sale or Rent Price*</label>': '>Satış veya Kira Fiyatı*</label>',
    '>Before Price Label</label>': '>Eski Fiyat Etiketi</label>',
    '>After Price Label</label>': '>Yeni Fiyat Etiketi</label>',
    '>Property ID*</label>': '>Emlak No*</label>',
    '>Video URL</label>': '>Video URL</label>',
    '>Address*</label>': '>Adres*</label>',
    '>Country</label>': '>Ülke</label>',
    '>City</label>': '>Şehir</label>',
    '>State</label>': '>Eyalet/Bölge</label>',
    '>Zip/Postal Code</label>': '>Posta Kodu</label>',
    '>Neighborhood</label>': '>Mahalle</label>',
    'value="Save Edits"': 'value="Düzenlemeleri Kaydet"',
    '>Select property country</option>': '>Ülke Seçin</option>',
    'placeholder="Enter your property address"': 'placeholder="Emlak adresinizi girin"',
    'placeholder="Youtube, Vimeo, Dailymotion, etc.."': 'placeholder="Youtube, Vimeo, Dailymotion, vb.."',
    'placeholder="sq ft"': 'placeholder="m²"',
    'placeholder="ex: start from"': 'placeholder="ör: başlangıç"',
    'placeholder="ex: monthly"': 'placeholder="ör: aylık"',

    # Property Features
    '>Center Cooling</p>': '>Merkezi Soğutma</p>',
    '>Balcony</p>': '>Balkon</p>',
    '>Pet Friendly</p>': '>Evcil Hayvan Dostu</p>',
    '>Fire Alarm</p>': '>Yangın Alarmı</p>',
    '>Modern Kitchen</p>': '>Modern Mutfak</p>',
    '>Storage</p>': '>Depo</p>',
    '>Heating</p>': '>Isıtma</p>',
    '>Pool</p>': '>Havuz</p>',
    '>Laundry</p>': '>Çamaşır</p>',
    '>Gym</p>': '>Spor Salonu</p>',
    '>Elevator</p>': '>Asansör</p>',
    '>Dish Washer</p>': '>Bulaşık Makinesi</p>',
    '>Emergency Exit</p>': '>Acil Çıkış</p>',
    '>Sauna</p>': '>Sauna</p>',
    '>Dryer</p>': '>Kurutucu</p>',
    '>Barbeque</p>': '>Barbekü</p>',
    '>First Floor</a>': '>Birinci Kat</a>',
    '>Second Floor</a>': '>İkinci Kat</a>',

    # Review Form
    '>Your Name*</label>': '>Adınız*</label>',
    '>Your Email*</label>': '>E-postanız*</label>',
    '>Rating*</label>': '>Puan*</label>',
    '>Review*</label>': '>Yorum*</label>',
    '>Submit</button>': '>Gönder</button>',
    '>Message*</label>': '>Mesaj*</label>',
    'placeholder="(optional)"': 'placeholder="(isteğe bağlı)"',
    # Property City Links (Map IDs to Turkish Cities)
    'href="properties-grid.html?city=New York"': 'href="properties-grid.html?city=İstanbul"',
    'href="properties-grid.html?city=Chicago"': 'href="properties-grid.html?city=Ankara"',
    'href="properties-grid.html?city=Manhatten"': 'href="properties-grid.html?city=İzmir"',
    'href="properties-grid.html?city=Los Angeles"': 'href="properties-grid.html?city=Antalya"',

    # Additional Address Mappings for Consistency
    '127 Kent Street, Sydney, NSW 2000': '127 Kent Street, İstanbul, 2000',
    '1035 Oglesby Ave, Chicago, IL 60617': '1035 Oglesby Ave, Ankara, 60617',
    '34 Long St, Jersey City, NJ 07305': '34 Long St, Antalya, 07305',
    '1445 N State Pkwy, Chicago, IL 60610': '1445 N State Pkwy, Ankara, 60610',
    '>For Sale</option>': '>Satılık</option>',
    '>Beds</option>': '>Yatak</option>',
    '>Baths</option>': '>Banyo</option>',
    '>Warehouse</option>': '>Depo</option>',
    '>Land</option>': '>Arsa</option>',
    '>Commercial</option>': '>Ticari</option>',
    '>Area Size:</label>': '>Alan Boyutu:</label>',
    '>Center Cooling</span>': '>Merkezi Soğutma</span>',
    '>Balcony</span>': '>Balkon</span>',
    '>Pet Friendly</span>': '>Evcil Hayvan Dostu</span>',
    '>Barbeque</span>': '>Barbekü</span>',
    '>Fire Alarm</span>': '>Yangın Alarmı</span>',
    '>Modern Kitchen</span>': '>Modern Mutfak</span>',
    '>Storage</span>': '>Depo</span>',
    '>Dryer</span>': '>Kurutucu</span>',
    '>Heating</span>': '>Isıtma</span>',
    '>Pool</span>': '>Havuz</span>',
    '>Laundry</span>': '>Çamaşırhane</span>',
    '>Sauna</span>': '>Sauna</span>',
    '>Gym</span>': '>Spor Salonu</span>',
    '>Elevator</span>': '>Asansör</span>',
    '>Dish Washer</span>': '>Bulaşık Makinesi</span>',
    '>Emergency Exit</span>': '>Acil Çıkış</span>',
    '>More options</a>': '>Daha fazla seçenek</a>',
    '>Less options</a>': '>Daha az seçenek</a>',

    # Profile & Social Pages
    '>Edit Profile</a>': '>Profili Düzenle</a>',
    '>Social Profiles</a>': '>Sosyal Profiller</a>',
    '>Social Profiles</h4>': '>Sosyal Profiller</h4>',
    '>My Properties</a>': '>İlanlarım</a>',
    '>Favorite Properties</a>': '>Favorilerim</a>',
    '>Add Property</a>': '>İlan Ekle</a>',
    '>Personal Details</h4>': '>Kişisel Bilgiler</h4>',
    '>First Name</label>': '>Adınız</label>',
    '>Last Name</label>': '>Soyadınız</label>',
    '>Email Address</label>': '>E-posta Adresi</label>',
    '>Phone</label>': '>Telefon</label>',
    '>About Me</label>': '>Hakkımda</label>',
    '>Change Password</h4>': '>Şifre Değiştir</label>',
    '>password</label>': '>Şifre</label>',
    '>confirm password</label>': '>Şifreyi Onayla</label>',
    'value="Save Edits"': 'value="Değişiklikleri Kaydet"',
    '>Profile Picture</h4>': '>Profil Resmi</h4>',
    '>Upload': '>Yükle',
    '>Delete</a>': '>Sil</a>',
    '>Facebook URL">': '>Facebook URL">',
    '>@Username">': '>Kullanıcı Adı@">',
    '>google-plus URL">': '>Google Plus URL">',
    '>LinkedIn URL">': '>LinkedIn URL">',
    '>Instagram</label>': '>Instagram</label>',
    '>Pinterest</label>': '>Pinterest</label>',
    '>user Profile</h1>': '>Kullanıcı Profili</h1>',
    '>user Profile</li>': '>Kullanıcı Profili</li>',
    '>Social Profile</h1>': '>Sosyal Profil</h1>',
    '>Social Profile</li>': '>Sosyal Profil</li>',

    # Add Property Page
    '>Add Property</h1>': '>İlan Ekle</h1>',
    '>Add Property</li>': '>İlan Ekle</li>',
    '>Property Description</h4>': '>Emlak Açıklaması</h4>',
    '>Property Title*</label>': '>Emlak Başlığı*</label>',
    '>Property Description*</label>': '>Emlak Açıklaması*</label>',
    '>Type</label>': '>Tür</label>',
    '>Status</label>': '>Durum</label>',
    '>Sale</option>': '>Satılık</option>',
    '>Rent</option>': '>Kiralık</option>',
    '>Location</label>': '>Konum</label>',
    '>Bedrooms</label>': '>Yatak Odası</label>',
    '>Bathrooms</label>': '>Banyo</label>',
    '>Floors</label>': '>Kat</label>',
    '>Garages</label>': '>Garaj</label>',
    '>Area</label>': '>Alan</label>',
    '>Size</label>': '>Boyut</label>',
    '>Sale or Rent Price*</label>': '>Satış veya Kira Fiyatı*</label>',
    '>Before Price Label</label>': '>Fiyat Etiketi (Önce)</label>',
    '>After Price Label</label>': '>Fiyat Etiketi (Sonra)</label>',
    '>Property ID*</label>': '>Emlak No*</label>',
    '>Video URL</label>': '>Video URL</label>',
    '>Property Features</h4>': '>Emlak Özellikleri</h4>',
    '>Property Gallery</h4>': '>Emlak Galerisi</h4>',
    '>Property Location</h4>': '>Emlak Konumu</h4>',
    '>Address*</label>': '>Adres*</label>',
    '>Country</label>': '>Ülke</label>',
    '>City</label>': '>Şehir</label>',
    '>State</label>': '>Eyalet/Bölge</label>',
    '>Zip/Postal Code</label>': '>Posta Kodu</label>',
    '>Neighborhood</label>': '>Mahalle</label>',
    '>Select property country</option>': '>Ülke Seçin</option>',
    'placeholder="Enter your property address"': 'placeholder="Emlak adresinizi girin"',
    'placeholder="Youtube, Vimeo, Dailymotion, etc.."': 'placeholder="Youtube, Vimeo, Dailymotion, vb.."',
    'placeholder="ex: start from"': 'placeholder="örn: den başlayan fiyatlarla"',
    'placeholder="ex: monthly"': 'placeholder="örn: aylık"',
    'placeholder="sq ft"': 'placeholder="ft kare"',

    # Addresses & Maps (Inline Scripts)
    'address: "121 King St,Melbourne, Australia"': 'address: "121 King St, Melbourne, Avustralya"',
    'address: "Melbourne, Australia"': 'address: "Melbourne, Avustralya"',
    '86 Petersham town, New South Wales Wardll Street, Australia PA 6550': '86 Petersham kasabası, Yeni Güney Galler Wardll Caddesi, Avustralya PA 6550',
    '86 Petersham town, Wardll street Australia PA 6550.': '86 Petersham kasabası, Wardll caddesi Avustralya PA 6550.',

    
    # Agent Profile & Contact
    '>Buying Agent': '>Emlak Danışmanı',
    '>Selling Agent': '>Satış Danışmanı',
    '>Real Estate Broker': '>Emlak Brokerı',
    '>Company</h5>': '>Şirket</h5>',
    '>Learn More</h5>': '>Daha Fazla</h5>',
    '>Agent Profile</h1>': '>Emlakçı Profili</h1>',
    '>Agent Profile</li>': '>Emlakçı Profili</li>',
    '>Phone:</span>': '>Telefon:</span>',
    '>Mobile:</span>': '>Cep:</span>',
    '>Fax:</span>': '>Faks:</span>',
    '>Website:</span>': '>Web:</span>',
    '>Email:</span>': '>E-posta:</span>',
    '>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercit.': 
    '>Yerel pazarda geniş deneyime sahip emlak danışmanı, sorunsuz ve başarılı bir alım satım deneyimi sağlamak için müşterilere en iyi hizmeti ve danışmanlığı sunmayı taahhüt eder.',

    # Property Listings & Details
    '>Beds:</span>': '>Yatak:</span>',
    '>Baths:</span>': '>Banyo:</span>',
    '>Area:</span>': '>Alan:</span>',
    '>sq ft</span>': '>ft²</span>',
    '>Garages:</span>': '>Garaj:</span>',
    '>Apartment in': '>Daire -',
    '>Villa in': '>Villa -',
    '>House in': '>Ev -',
    '>Find Your Favorite Property</h1>': '>Favori Mülkünüzü Bulun</h1>',

    # Locations (Dropdowns) - Hierarchical Search Request
    '>Any Location</option>': '>Ülke / Şehir / Semt / Mahalle</option>',
    '>Alabama</option>': '>Ülke</option>',
    '>Alaska</option>': '>Şehir</option>',
    '>California</option>': '>Semt / Bölge</option>',
    '>Florida</option>': '>Mahalle</option>',
    '>Mississippi</option>': '>Seçilen Konum</option>',
    '>Oregon</option>': '>Tüm Konumlar</option>',

    # Simple Steps Section (Domain Specific Content)
    '>Simple Steps</h2>': '>Basit Adımlar</h2>',
    '>Search For Real Estates</h3>': '>Gayrimenkul Ara</h3>',
    '>Select Your Favorite</h3>': '>Favorini Seç</h3>',
    '>Take Your Key</h3>': '>Anahtarını Teslim Al</h3>',
    '>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>': 
    '>Yeni evinize en hızlı ve en az çabayla ulaşmanız için arama, seçim ve sözleşme sürecini sizin için kolaylaştırıyoruz.</p>',

    # Specific Step Descriptions
    '<h3>Search For Real Estates</h3>\n                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>':
    '<h3>Gayrimenkul Ara</h3>\n                                <p>Gelişmiş arama filtrelerini kullanarak ihtiyaçlarınıza ve bütçenize uygun geniş portföyümüzden aramaya başlayın.</p>',
    
    '<h3>Select Your Favorite</h3>\n                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>':
    '<h3>Favorini Seç</h3>\n                                <p>Tüm detayları ve fotoğrafları inceleyin, beklentilerinizi karşılayan mükemmel mülkü bulmak için farklı seçenekleri karşılaştırın.</p>',
    
    '<h3>Take Your Key</h3>\n                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eule pariate.</p>':
    '<h3>Anahtarını Teslim Al</h3>\n                                <p>Uzman ekibimizle sözleşme süreçlerini kolayca tamamlayın ve yeni hayatınıza başlamak için evinize taşının.</p>',


    # Specific Section Placeholders - index.html
    '>Latest Properties</h2>\n                            <p class="heading--desc">Discover the latest premium properties available for sale or rent in carefully selected strategic locations.</p>':
    '>Son İlanlar</h2>\n                            <p class="heading--desc">En iyi stratejik konumlarda satılık veya kiralık mevcut olan en son seçkin mülkleri keşfedin.</p>',

    '>Simple Steps</h2>\n                            <p class="heading--desc">We provide you with an integrated real estate experience and clear steps that start from searching and end with receiving the key to your new home.</p>':
    '>Kolay Adımlar</h2>\n                            <p class="heading--desc">Aramadan başlayarak yeni evinizin anahtarını kolaylıkla teslim almaya kadar size entegre bir deneyim sunuyoruz.</p>',

    '>Property By City</h2>\n                            <p class="heading--desc">Browse available properties in the most prestigious cities and regions, where we provide you with a comprehensive and diverse list.</p>':
    '>Şehre Göre Emlak</h2>\n                            <p class="heading--desc">En prestijli şehir ve bölgelerdeki mülklere göz atın, yatırım ve konut beklentilerinizi karşılayan seçenekler sunuyoruz.</p>',

    '>Trusted Agents</h2>\n                            <p class="heading--desc">A selection of the best real estate agents with high experience and competence to help you make the best real estate decisions.</p>':
    '>Güvenilir Emlakçılar</h2>\n                            <p class="heading--desc">Emlak işlemlerinizde size yardımcı olacak, yüksek deneyime ve yetkinliğe sahip seçkin emlakçılar.</p>',

    # Agent List Placeholders
    '>A professional real estate agent committed to providing the best consulting services to ensure a successful experience for all clients.</p>':
    '>Tüm müşteriler için başarılı bir deneyim sağlamaya kendini adamış profesyonel gayrimenkul danışmanı.</p>',

    # Simple Steps Panel Descriptions
    '<h3>Search For Real Estates</h3>\n                                <p>Start searching through our wide collection of premium properties that suit your needs and budget through advanced search filters.</p>':
    '<h3>Gayrimenkul Ara</h3>\n                                <p>Gelişmiş arama filtreleri aracılığıyla ihtiyaçlarınıza ve bütçenize uygun geniş seçkin emlak koleksiyonumuzda aramaya başlayın.</p>',

    '<h3>Select Your Favorite</h3>\n                                <p>Browse full details and photos, and compare different options to find the perfect property that meets your expectations.</p>':
    '<h3>Favorini Seç</h3>\n                                <p>Beklentilerinizi karşılayan mükemmel mülkü bulmak için tüm detaylara ve fotoğraflara göz atın, farklı seçenekleri karşılaştırın.</p>',

    '<h3>Take Your Key</h3>\n                                <p>Complete the contracting procedures easily with our specialized team, and move to your new home to start a new and stable life.</p>':
    '<h3>Anahtarını Teslim Al</h3>\n                                <p>Uzman ekibimizle sözleşme prosedürlerini kolayca tamamlayın ve yeni, istikrarlı bir hayata başlamak için yeni evinize taşının.</p>',

    # Location Dropdown
    '>Country / City / Locality / Neighborhood</option>': '>Ülke / Şehir / Semt / Mahalle</option>',
    '>State / City / Area / District</option>': '>İl / İlçe / Semt / Mahalle</option>',
    '>Any Country</option>': '>Tüm Ülkeler</option>',
    '>Any State</option>': '>Tüm İller</option>',
    '>Any City</option>': '>Tüm Şehirler</option>',
    '>Any Locality</option>': '>Tüm Semtler</option>',
    '>Any Neighborhood</option>': '>Tüm Mahalleler</option>',
    '&copy; 2024 Lalan Real Estate, All Rights Reserved.': '&copy; 2024 Lalan Gayrimenkul, Tüm Hakları Saklıdır.',


    # Missing Page Titles
    '>About Me</h1>': '>Hakkımda</h1>',
    '>About Me</a>': '>Hakkımda</a>',
    '>Properties List Split</a>': '>Emlak Listesi</a>',
    '>properties list split</a>': '>Emlak Listesi</a>',
    '>Properties List</a>': '>Emlak Listesi</a>',
    '>Properties Grid</a>': '>Emlak Izgarası</a>',
    '>Properties Grid Split</a>': '>Emlak Izgarası</a>',
    '>Single Gallery</a>': '>Galeri Görünümü</a>',
    '>Single Slider</a>': '>Slayt Görünümü</a>',
    '>single gallery</a>': '>Galeri Görünümü</a>',
    '>single slider</a>': '>Slayt Görünümü</a>',
    
    # Common Footer/Widgets
    '>Company</h5>': '>Şirket</h5>',
    '>Learn More</h5>': '>Daha Fazla</h5>',
    '>newsletter</h5>': '>Bülten</h5>',
    '>Get In Touch</h6>': '>İletişimde Kalın</h6>',
    '>Privacy</a>': '>Gizlilik</a>',

    # FAQ Page
    '>Find answers to the most common questions about buying, selling, and renting properties with our expert team.</p>': '>Uzman ekibimizle mülk satın alma, satma ve kiralama hakkındaki en yaygın soruların yanıtlarını bulun.</p>',
    '<h3>What is a real estate broker?</h3>': '<h3>Gayrimenkul komisyoncusu nedir?</h3>',
    '>A real estate broker is a licensed professional who represents sellers or buyers of real estate. While a broker can work independently, they often lead a team of agents to help clients navigate the complexities of property transactions.</p>': '>Gayrimenkul komisyoncusu, gayrimenkul satıcılarını veya alıcılarını temsil eden lisanslı bir profesyoneldir. Bir komisyoncu bağımsız olarak çalışabilse de, müşterilerin mülk işlemlerinin karmaşıklıklarında gezinmelerine yardımcı olmak için genellikle bir emlakçı ekibine liderlik ederler.</p>',
    '<h3>Why should I use a real estate salesperson?</h3>': '<h3>Neden bir gayrimenkul satış temsilcisi kullanmalıyım?</h3>',
    '>Working with a professional salesperson provides you with expert market analysis, negotiation skills, and access to a wider network of listings, ensuring you get the best possible deal while saving time and effort.</p>': '>Profesyonel bir satış temsilcisiyle çalışmak size uzman pazar analizi, müzakere becerileri ve daha geniş bir ilan ağına erişim sağlayarak zaman ve emekten tasarruf ederken mümkün olan en iyi anlaşmayı elde etmenizi sağlar.</p>',
    '<h3>What if my offer is rejected?</h3>': '<h3>Teklifim reddedilirse ne olur?</h3>',
    '>If your offer is rejected, don’t be discouraged. We will analyze the feedback, adjust our strategy, and continue searching for the right property that meets your needs and budget.</p>': '>Teklifiniz reddedilirse cesaretiniz kırılmasın. Geri bildirimleri analiz edecek, stratejimizi ayarlayacak ve ihtiyaçlarınızı ve bütçenizi karşılayan doğru mülkü aramaya devam edeceğiz.</p>',
    '<h3>Should I buy or continue to rent?</h3>': '<h3>Satın mı almalıyım yoksa kiralamaya devam mı etmeliyim?</h3>',
    '>The decision depends on your financial goals and lifestyle. Buying builds equity and provides stability, while renting offers flexibility. We can provide a detailed comparison to help you make the best choice for your future.</p>': '>Karar mali hedeflerinize ve yaşam tarzınıza bağlıdır. Satın almak sermaye oluşturur ve istikrar sağlar, kiralamak ise esneklik sunar. Geleceğiniz için en iyi seçimi yapmanıza yardımcı olacak ayrıntılı bir karşılaştırma sunabiliriz.</p>',

    # About Us Page Features (New)
    '>We use high-quality photography and virtual tours to showcase your property\'s best features and attract the right buyers.</p>': '>Mülkünüzün en iyi özelliklerini sergilemek ve doğru alıcıları çekmek için yüksek kaliteli fotoğrafçılık ve sanal turlar kullanıyoruz.</p>',
    '>Whether you\'re looking to rent out or sell your property, we provide expert guidance to maximize your returns.</p>': '>Mülkünüzü kiralamak veya satmak istiyor olun, getirilerinizi maksimize etmek için uzman rehberliği sağlıyoruz.</p>',
    '>Our specialized team handles the complexities of property exchange, ensuring a fair and smooth transition for all parties.</p>': '>Uzman ekibimiz, mülk değişiminin karmaşıklıklarını yöneterek tüm taraflar için adil ve sorunsuz bir geçiş sağlar.</p>',
    '>We help you find the perfect property that fits your lifestyle and investment goals, guiding you through every step of the purchase.</p>': '>Yaşam tarzınıza ve yatırım hedeflerinize uygun mükemmel mülkü bulmanıza yardımcı oluyor, satın almanın her adımında size rehberlik ediyoruz.</p>',
    '>Our agents are highly professional and dedicated to helping you find your dream home or sell your property for the best price.</p>': '>Emlakçılarımız son derece profesyoneldir ve hayalinizdeki evi bulmanıza veya mülkünüzü en iyi fiyata satmanıza yardımcı olmaya kendilerini adamışlardır.</p>',
    '>A committed real estate professional with extensive knowledge of the local market, dedicated to providing exceptional service.</p>': '>Yerel pazar hakkında kapsamlı bilgiye sahip, olağanüstü hizmet sunmaya kendini adamış, kararlı bir gayrimenkul profesyoneli.',

    # Home Pages (Map/Property)
    '>Explore our newest property listings, from luxury villas to modern apartments, and find your perfect home today.</p>': '>Bugün lüks villalardan modern dairelere kadar en yeni emlak ilanlarımızı keşfedin ve mükemmel evinizi bulun.</p>',
    '>Follow our straightforward process to find, select, and secure your next premium property with ease.</p>': '>Bir sonraki seçkin mülkünüzü kolaylıkla bulmak, seçmek ve güvence altına almak için basit sürecimizi takip edin.</p>',
    '>Discover a wide range of properties tailored to your needs using our advanced search tools and expert local knowledge.</p>': '>Gelişmiş arama araçlarımızı ve uzman yerel bilgilerimizi kullanarak ihtiyaçlarınıza göre uyarlanmış geniş bir mülk yelpazesini keşfedin.</p>',
    '>Compare listings and choose the property that best fits your lifestyle, investment goals, and family needs.</p>': '>İlanları karşılaştırın ve yaşam tarzınıza, yatırım hedeflerinize ve aile ihtiyaçlarınıza en uygun mülkü seçin.</p>',
    '>Experience a seamless closing process and receive the keys to your new home with our professional guidance.</p>': '>Profesyonel rehberliğimizle sorunsuz bir kapanış süreci yaşayın ve yeni evinizin anahtarını teslim alın.</p>',
    '>Find the most exclusive real estate opportunities in top-tier cities, carefully selected for quality and value.</p>': '>Kalite ve değer açısından özenle seçilmiş, birinci sınıf şehirlerdeki en seçkin gayrimenkul fırsatlarını bulun.</p>',
    '>Account</a>': '>Hesap</a>',
    '>Career</a>': '>Kariyer</a>',
    '>Services</a>': '>Hizmetler</a>',
    
    # Actions & Buttons
    '>Login</a>': '>Giriş</a>',
    '>Login with Facebook</a>': '>Facebook ile Giriş</a>',
    '>Sign In': 'Giriş Yap',
    '>Register</a>': '>Kayıt Ol</a>',
    '>Register with Facebook</a>': '>Facebook ile Kayıt</a>',
    '>Signup</a>': '>Kayıt</a>',
    '>signup</a>': '>Kayıt</a>',
    'value="Register"': 'value="Kayıt Ol"',
    'value="Sign In"': 'value="Giriş Yap"',
    'placeholder="Email Address"': 'placeholder="E-posta Adresi"',
    'placeholder="Password"': 'placeholder="Şifre"',
    'placeholder="Full Name"': 'placeholder="Ad Soyad"',
    '>Remember Me</span>': '>Beni Hatırla</span>',
    '>Forget your password?</a>': '>Şifremi Unuttum?</a>',
    '>I agree with all <a': '>Tümünü kabul ediyorum <a',
    '>Terms & Conditions</a>': '>Şartlar ve Koşullar</a>',
    
    # Hero / Search
    '>Find Your Favorite Property</h1>': '>Hayalinizdeki Evi Bulun</h1>',
    '>Any Location</option>': '>Tüm Konumlar</option>',
    '>Any Type</option>': '>Tüm Tipler</option>',
    '>Any Status</option>': '>Tüm Durumlar</option>',
    'value="Search"': 'value="Ara"',
    '>More options</a>': '>Daha Fazla Seçenek</a>',
    '>Price Range: </label>': '>Fiyat Aralığı: </label>',
    
    # Footer / Misc
    '>Quick Links</h3>': '>Hızlı Linkler</h3>',
    '>Contact Us</h3>': '>Bize Ulaşın</h3>',
    '>Follow Us</h3>': '>Bizi Takip Edin</h3>',
    '>Latest Properties</h2>': '>Son İlanlar</h2>',
    '>Simple Steps</h2>': '>Kolay Adımlar</h2>',
    '>Trusted Agents</h2>': '>Güvenilir Emlakçılar</h2>',
    '>Property By City</h2>': '>Şehre Göre Emlak</h2>',
    
    # Common words in context
    '>Beds:</span>': '>Yatak:</span>',
    '>Baths:</span>': '>Banyo:</span>',
    '>Area:</span>': '>Alan:</span>',
    '>For Sale</span>': '>Satılık</span>',
    '>For Rent</span>': '>Kiralık</span>',
    '>month</span>': '>ay</span>',

    # New Professional Content
    '>Trusted Real Estate Experts Since 2008</h2>': '>2008\'den Beri Güvenilir Gayrimenkul Uzmanları</h2>',
    '>To be the most reliable and innovative real estate partner, setting the standard for excellence and integrity in every transaction.</p>': '>Her işlemde mükemmellik ve dürüstlük standartlarını belirleyen, en güvenilir ve yenilikçi gayrimenkul ortağı olmak.</p>',
    '>To deliver exceptional results for our clients through personalized service, expert market insights, and a global network of opportunities.</p>': '>Kişiselleştirilmiş hizmet, uzman pazar içgörüleri ve küresel bir fırsat ağı aracılığıyla müşterilerimiz için olağanüstü sonuçlar sunmak.</p>',
    '>Why Choose Us?</h2>': '>Neden Bizi Seçmelisiniz?</h2>',
    '>Our expertise and dedication ensure you receive the highest level of service and the best outcomes for your real estate journey.</p>': '>Uzmanlığımız ve özverimiz, gayrimenkul yolculuğunuz için en üst düzeyde hizmet ve en iyi sonuçları almanızı sağlar.</p>',
    'A leading real estate agency with over 15 years of experience in the local and international markets, specializing in luxury residential and commercial properties. Our team of dedicated experts provides comprehensive consulting services to help you find the perfect property that meets your needs and investment goals.': 'Lüks konut ve ticari mülklerde uzmanlaşmış, yerel ve uluslararası pazarlarda 15 yılı aşkın deneyime sahip lider bir gayrimenkul ajansı. Kendini işine adamış uzman ekibimiz, ihtiyaçlarınızı ve yatırım hedeflerinizi karşılayan mükemmel mülkü bulmanıza yardımcı olmak için kapsamlı danışmanlık hizmetleri sunar.',
    'Our agency stands at the forefront of the real estate industry, offering a curated selection of residential and commercial properties. We pride ourselves on transparency, integrity, and a personalized approach that ensures every client makes an informed and successful decision.': 'Gayrimenkul sektörünün ön saflarında yer alan ajansımız, konut ve ticari mülklerden oluşan seçkin bir seçki sunmaktadır. Şeffaflık, dürüstlük ve her müşterinin bilinçli ve başarılı bir karar vermesini sağlayan kişiselleştirilmiş bir yaklaşımla gurur duyuyoruz.',
    "Expert advice on navigating the current housing market, from securing the best mortgage rates to finding your dream home.": "En iyi ipotek oranlarını güvence altına almaktan hayalinizdeki evi bulmaya kadar, mevcut emlak piyasasında gezinmek için uzman tavsiyesi.",
    "Learn how to maximize your property's value with effective marketing strategies and home staging tips that attract buyers.": "Etkili pazarlama stratejileri ve alıcıları çeken ev düzenleme ipuçlarıyla mülkünüzün değerini nasıl en üst düzeye çıkaracağınızı öğrenin.",
    "A comprehensive guide to understanding property investments and how to build a diversified portfolio in today's landscape.": "Gayrimenkul yatırımlarını anlamak ve günümüz manzarasında nasıl çeşitli bir portföy oluşturulacağına dair kapsamlı bir rehber.",
    "Discover the power of visual storytelling in real estate and how professional video content can transform your property listings.": "Gayrimenkulde görsel hikaye anlatımının gücünü ve profesyonel video içeriğinin mülk listelerinizi nasıl dönüştürebileceğini keşfedin.",
    "Build a loyal community and long-term client relationships by providing consistent, high-quality value through your digital platforms.": "Dijital platformlarınız aracılığıyla sürekli olarak yüksek kaliteli değer sağlayarak sadık bir topluluk ve uzun vadeli müşteri ilişkileri kurun.",
    "Master the art of email marketing to stay top-of-mind with your prospects and nurture leads into successful real estate transactions.": "Potansiyel müşterilerinizin zihninde taze kalmak ve olası satışları başarılı gayrimenkul işlemlerine dönüştürmek için e-posta pazarlama sanatında ustalaşın.",
    'With a presence in key metropolitan areas, we bring together a network of professional agents who are passionate about delivering exceptional results and building long-term value for our clients through expert consulting and dedicated support.': 'Önemli metropol bölgelerindeki varlığımızla, uzman danışmanlık ve özel destek aracılığıyla olağanüstü sonuçlar sunma ve müşterilerimiz için uzun vadeli değer yaratma konusunda tutkulu profesyonel acentelerden oluşan bir ağı bir araya getiriyoruz.',
    'Navigating the real estate market requires both patience and expertise. Whether you\'re a first-time homebuyer or a seasoned investor, understanding current trends and property values is essential for making a sound investment that grows over time.': 'Gayrimenkul piyasasında gezinmek hem sabır hem de uzmanlık gerektirir. İster ilk kez ev alıyor olun ister deneyimli bir yatırımcı, mevcut trendleri ve mülk değerlerini anlamak, zamanla büyüyen sağlam bir yatırım yapmak için gereklidir.',
    'Success in real estate is built on trust, transparency, and deep market insights. Every property has a story, and our mission is to help you find the one that perfectly aligns with your vision for the future.': 'Gayrimenkulde başarı güven, şeffaflık ve derin pazar içgörüleri üzerine kuruludur. Her mülkün bir hikayesi vardır ve misyonumuz, gelecek vizyonunuzla mükemmel şekilde uyum sağlayan mülkü bulmanıza yardımcı olmaktır.',
    'From legal documentation to financial planning, the process should be handled with professional care. We ensure every detail is meticulously reviewed to provide you with peace of mind and a seamless experience.': 'Yasal belgelerden finansal planlamaya kadar, süreç profesyonel bir titizlikle yürütülmelidir. Size huzur ve sorunsuz bir deneyim sunmak için her detayın titizlikle gözden geçirilmesini sağlıyoruz.',
    'Our team of experts is dedicated to providing you with the most up-to-date information and personalized advice. We believe that an informed client is an empowered client, and we strive to be your most reliable source for all real estate matters and investment opportunities.': 'Uzman ekibimiz size en güncel bilgileri ve kişiselleştirilmiş tavsiyeleri sunmaya kendini adamıştır. Bilgili bir müşterinin yetkin bir müşteri olduğuna inanıyoruz ve tüm gayrimenkul konuları ve yatırım fırsatları için en güvenilir kaynağınız olmaya çalışıyoruz.',
    'Excellent service and very professional approach. The team helped me find my dream home in record time. Highly recommended for anyone looking for reliability and expertise in real estate.': 'Mükemmel hizmet ve çok profesyonel bir yaklaşım. Ekip, hayalimdeki evi rekor sürede bulmama yardımcı oldu. Gayrimenkulde güvenilirlik ve uzmanlık arayan herkese şiddetle tavsiye edilir.',
    'This stunning property offers modern architecture and premium finishes throughout. Featuring spacious living areas, a state-of-the-art kitchen, and breathtaking views, it provides the perfect blend of luxury and comfort for modern living.': 'Bu muhteşem mülk, modern mimari ve her yerde birinci sınıf kaplamalar sunmaktadır. Geniş yaşam alanları, son teknoloji ürünü bir mutfak ve nefes kesici manzaralar sunarak modern yaşam için lüks ve konforun mükemmel bir karışımını sağlar.',
    'The layout has been meticulously designed to optimize space and ensure a seamless transition between indoor and outdoor environments, making it an ideal choice for families and professionals alike.': 'Yerleşim düzeni, alanı optimize etmek ve iç ile dış mekanlar arasında sorunsuz bir geçiş sağlamak için titizlikle tasarlanmıştır ve bu da onu hem aileler hem de profesyoneller için ideal bir seçim haline getirir.',
    'The open-concept layout maximizes natural light and flow between living spaces. Each room is designed with attention to detail and high-quality materials to provide a functional and elegant environment for any lifestyle.': 'Açık konsept düzen, doğal ışığı ve yaşam alanları arasındaki akışı maksimize eder. Her oda, her türlü yaşam tarzı için işlevsel ve zarif bir ortam sağlamak amacıyla detaylara dikkat edilerek ve yüksek kaliteli malzemelerle tasarlanmıştır.',
}


def inject_lang_switcher(content, filename_base):
    en_link = f"{filename_base}.html"
    ar_link = f"{filename_base}_ar.html"
    tr_link = f"{filename_base}_tr.html"
    
    switcher_html = LANG_SWITCHER_TEMPLATE.format(en_link=en_link, ar_link=ar_link, tr_link=tr_link)
    
    # Robust Regex to capture the switcher block (even if corrupted/duplicated)
    # Matches from <!-- Language Switcher --> until it hits <!-- Module Signup or <div class="module
    # We use lookahead (?=...) to peek but not consume the following tag
    start_marker = "<!-- Language Switcher -->"
    
    if start_marker in content:
        # Regex to find the span to replace
        # We want to replace everything starting from start_marker UP TO the next significant block
        cleanup_pattern = re.compile(r'<!-- Language Switcher -->[\s\S]*?(?=(?:<!-- Module Signup|<div class="module))', re.IGNORECASE)
        
        # Check if it matches
        if cleanup_pattern.search(content):
            # We also need to ensure we keep the </ul> closing the nav if it was part of the match?
            # Wait, the switcher is INSIDE the <ul>.
            # The structure is:
            # <ul ...>
            #    ...
            #    <!-- Language Switcher -->
            #    <li>...</li>
            # </ul>
            # <!-- Module Signup -->
            
            # The regex `[\s\S]*?(?=<!-- Module Signup)` would consume the closing `</ul>` of the navbar!
            # We MUST NOT eat the closing `</ul>`.
            
            # The switcher is the *last* item in the user list usually.
            # But the `</ul>` comes *after* the switcher.
            
            # Match everything until the `</ul>` that ends the navbar.
            # This is identified by looking ahead for `</ul>` followed by the Signup Module.
            cleanup_pattern = re.compile(r'<!-- Language Switcher -->[\s\S]*?(?=</ul>\s*(?:<!-- Module Signup|<div class="module))', re.IGNORECASE)
            
            return cleanup_pattern.sub(switcher_html, content)

    match = NAVBAR_END_REGEX.search(content)

    if match:
        return content[:match.start()] + switcher_html + content[match.start():]
    
    match = FALLBACK_NAVBAR_END_REGEX.search(content)
    if match:
        return content[:match.start()] + switcher_html + content[match.start():]
        
    # print(f"Warning: Could not find navbar insertion point in {filename_base}")
    return content

def apply_translations(content, translations):
    # Sort by length descending
    sorted_items = sorted(translations.items(), key=lambda x: len(x[0]), reverse=True)
    
    for eng, trans in sorted_items:
        # Fast path: exact match
        if eng in content:
            content = content.replace(eng, trans)
            continue
            
        # Slow path: flexible whitespace match (handles line wraps)
        # Avoid regex if the string is very short or unlikely to be wrapped
        if len(eng) < 20: 
            continue
            
        # Normalize pattern
        pattern = re.escape(eng).replace(r'\ ', r'\s+').replace(r'\n', r'\s+').replace(r'\t', r'\s+')
        pattern = re.sub(r'(\\s\+)+', r'\\s+', pattern)
        
        try:
            content = re.sub(pattern, trans, content)
        except Exception:
            pass
            
    return content

def fix_internal_links(content, suffix, all_files):
    """
    Replaces links to other HTML files with their localized versions.
    e.g. href="about.html" -> href="about_ar.html"
    """
    for fname in all_files:
        # strict replacement for href="filename.html" or href='filename.html'
        # to avoid partial matches, though simpler string replace might suffice if filenames are unique enough.
        # sticky matches like "about.html" vs "page-about.html" are handled by descending length order if needed,
        # but here we can just do simple replace if we include quotes to be safe, or just replace .html
        
        # safely replace usages in hrefs
        pattern = r'href=["\']' + re.escape(fname) + r'["\']'
        
        def repl(m):
            quote = m.group(0)[5] # get " or '
            return f'href={quote}{os.path.splitext(fname)[0]}{suffix}{quote}'
            
        content = re.sub(pattern, repl, content, flags=re.IGNORECASE)
    
    return content

def process_files():
    # Gather all base HTML files first
    html_files = [os.path.basename(f) for f in glob.glob(os.path.join(BASE_DIR, "*.html")) 
                  if not f.endswith("_ar.html") and not f.endswith("_tr.html")]
    
    # Sort by length descending to avoid partial matches (e.g. replacing 'index.html' inside 'index-2.html' if we were loose)
    # But with strict href match it's less critical, still good practice.
    html_files.sort(key=len, reverse=True)

    for filename in html_files:
        file_path = os.path.join(BASE_DIR, filename)
        filename_base = os.path.splitext(filename)[0]
        
        print(f"Processing {filename}...")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            original_content = f.read()

        # --- Arabic Version ---
        ar_content = original_content
        ar_content = ar_content.replace('<html dir="ltr" lang="en-US">', '<html dir="rtl" lang="ar">')
        ar_content = ar_content.replace('<html lang="en">', '<html dir="rtl" lang="ar">')
        
        rtl_css_link = '<link href="assets/css/style-rtl.css" rel="stylesheet">'
        if rtl_css_link not in ar_content:
            ar_content = ar_content.replace('</head>', f'    {rtl_css_link}\n</head>')
        
        # Apply Translations
        ar_content = apply_translations(ar_content, AR_TRANSLATIONS)
        ar_content = fix_internal_links(ar_content, "_ar.html", html_files) # Fix links
        ar_content = inject_lang_switcher(ar_content, filename_base)
        ar_content = ar_content.replace('assets/js/map-addresses.js', 'assets/js/map-addresses_ar.js')
        
        ar_path = os.path.join(BASE_DIR, f"{filename_base}_ar.html")
        with open(ar_path, 'w', encoding='utf-8') as f:
            f.write(ar_content)
            
            
        # --- Turkish Version ---
        tr_content = original_content
        tr_content = tr_content.replace('<html dir="ltr" lang="en-US">', '<html lang="tr">')
        tr_content = tr_content.replace('<html lang="en">', '<html lang="tr">')
        
        # Apply Translations
        tr_content = apply_translations(tr_content, TR_TRANSLATIONS)
        tr_content = fix_internal_links(tr_content, "_tr.html", html_files) # Fix links
        tr_content = inject_lang_switcher(tr_content, filename_base)
        tr_content = tr_content.replace('assets/js/map-addresses.js', 'assets/js/map-addresses_tr.js')
        
        tr_path = os.path.join(BASE_DIR, f"{filename_base}_tr.html")
        with open(tr_path, 'w', encoding='utf-8') as f:
            f.write(tr_content)


        # --- Update Original English Version ---
        en_content = inject_lang_switcher(original_content, filename_base)
        
        if en_content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(en_content)

    print("Localization generation complete.")

if __name__ == "__main__":
    process_files()
